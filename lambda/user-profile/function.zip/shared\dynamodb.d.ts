import { DynamoDBDocumentClient } from '@aws-sdk/lib-dynamodb';
declare const ddb: DynamoDBDocumentClient;
declare const TABLE_NAME: string;
export declare class DynamoDBHelper {
    static get(PK: string, SK: string): Promise<Record<string, any> | undefined>;
    static put(item: any): Promise<import("@aws-sdk/lib-dynamodb").PutCommandOutput>;
    static update(PK: string, SK: string, updateExpression: string, expressionAttributeValues: any, expressionAttributeNames?: any): Promise<Record<string, any> | undefined>;
    static delete(PK: string, SK: string): Promise<import("@aws-sdk/lib-dynamodb").DeleteCommandOutput>;
    static query(params: {
        KeyConditionExpression: string;
        ExpressionAttributeValues: any;
        ExpressionAttributeNames?: any;
        FilterExpression?: string;
        IndexName?: string;
        ScanIndexForward?: boolean;
        Limit?: number;
        ExclusiveStartKey?: any;
    }): Promise<{
        Items: Record<string, any>[];
        LastEvaluatedKey: Record<string, any> | undefined;
        Count: number;
    }>;
    static scan(params?: {
        FilterExpression?: string;
        ExpressionAttributeValues?: any;
        ExpressionAttributeNames?: any;
        IndexName?: string;
        Limit?: number;
        ExclusiveStartKey?: any;
    }): Promise<{
        Items: Record<string, any>[];
        LastEvaluatedKey: Record<string, any> | undefined;
        Count: number;
    }>;
    static batchGet(keys: Array<{
        PK: string;
        SK: string;
    }>): Promise<Record<string, any>[]>;
    static batchWrite(items: Array<{
        PutRequest?: {
            Item: any;
        };
        DeleteRequest?: {
            Key: any;
        };
    }>): Promise<import("@aws-sdk/lib-dynamodb").BatchWriteCommandOutput>;
    static getUserProfile(userId: string): Promise<Record<string, any> | undefined>;
    static getUserPreferences(userId: string): Promise<Record<string, any> | undefined>;
    static getUserIngredients(userId: string): Promise<{
        Items: Record<string, any>[];
        LastEvaluatedKey: Record<string, any> | undefined;
        Count: number;
    }>;
    static getRecipe(recipeId: string): Promise<Record<string, any> | undefined>;
    static getRecipeIngredients(recipeId: string): Promise<{
        Items: Record<string, any>[];
        LastEvaluatedKey: Record<string, any> | undefined;
        Count: number;
    }>;
    static getCookingHistory(userId: string, favoritesOnly?: boolean): Promise<{
        Items: Record<string, any>[];
        LastEvaluatedKey: Record<string, any> | undefined;
        Count: number;
    }>;
    static getRecipeRatings(recipeId: string): Promise<{
        Items: Record<string, any>[];
        LastEvaluatedKey: Record<string, any> | undefined;
        Count: number;
    }>;
    static searchIngredients(searchTerm: string, limit?: number): Promise<{
        Items: Record<string, any>[];
        LastEvaluatedKey: Record<string, any> | undefined;
        Count: number;
    }>;
    static searchRecipesByMethod(cookingMethod: string, limit?: number): Promise<{
        Items: Record<string, any>[];
        LastEvaluatedKey: Record<string, any> | undefined;
        Count: number;
    }>;
    /**
     * Execute DynamoDB operation with retry logic and error handling
     */
    private static executeWithRetry;
}
export { ddb, TABLE_NAME };
