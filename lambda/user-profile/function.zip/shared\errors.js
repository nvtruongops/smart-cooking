"use strict";
/**
 * Centralized Error Handling System
 * Provides standardized error classes and HTTP response formatting
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.TimeoutError = exports.DatabaseError = exports.AIServiceError = exports.ServiceUnavailableError = exports.InternalError = exports.RateLimitError = exports.ConflictError = exports.ValidationError = exports.NotFoundError = exports.ForbiddenError = exports.UnauthorizedError = exports.BadRequestError = exports.AppError = exports.ErrorCode = void 0;
exports.formatErrorResponse = formatErrorResponse;
exports.isTransientError = isTransientError;
exports.getRetryDelay = getRetryDelay;
var ErrorCode;
(function (ErrorCode) {
    // Client errors (4xx)
    ErrorCode["BAD_REQUEST"] = "BAD_REQUEST";
    ErrorCode["UNAUTHORIZED"] = "UNAUTHORIZED";
    ErrorCode["FORBIDDEN"] = "FORBIDDEN";
    ErrorCode["NOT_FOUND"] = "NOT_FOUND";
    ErrorCode["CONFLICT"] = "CONFLICT";
    ErrorCode["VALIDATION_ERROR"] = "VALIDATION_ERROR";
    ErrorCode["RATE_LIMIT_EXCEEDED"] = "RATE_LIMIT_EXCEEDED";
    // Server errors (5xx)
    ErrorCode["INTERNAL_ERROR"] = "INTERNAL_ERROR";
    ErrorCode["SERVICE_UNAVAILABLE"] = "SERVICE_UNAVAILABLE";
    ErrorCode["AI_SERVICE_ERROR"] = "AI_SERVICE_ERROR";
    ErrorCode["DATABASE_ERROR"] = "DATABASE_ERROR";
    ErrorCode["TIMEOUT"] = "TIMEOUT";
})(ErrorCode || (exports.ErrorCode = ErrorCode = {}));
/**
 * Base application error class
 */
class AppError extends Error {
    constructor(errorDetails) {
        super(errorDetails.message);
        this.name = this.constructor.name;
        this.code = errorDetails.code;
        this.statusCode = errorDetails.statusCode;
        this.details = errorDetails.details;
        this.recoverable = errorDetails.recoverable ?? false;
        this.recoverySuggestion = errorDetails.recoverySuggestion;
        this.timestamp = new Date().toISOString();
        Error.captureStackTrace(this, this.constructor);
    }
    toJSON() {
        return {
            error: {
                code: this.code,
                message: this.message,
                details: this.details,
                recoverable: this.recoverable,
                recoverySuggestion: this.recoverySuggestion,
                timestamp: this.timestamp,
            },
        };
    }
}
exports.AppError = AppError;
/**
 * Client error classes (4xx)
 */
class BadRequestError extends AppError {
    constructor(message, details) {
        super({
            code: ErrorCode.BAD_REQUEST,
            message,
            statusCode: 400,
            details,
            recoverable: true,
            recoverySuggestion: 'Please check your request and try again.',
        });
    }
}
exports.BadRequestError = BadRequestError;
class UnauthorizedError extends AppError {
    constructor(message = 'Authentication required') {
        super({
            code: ErrorCode.UNAUTHORIZED,
            message,
            statusCode: 401,
            recoverable: true,
            recoverySuggestion: 'Please log in and try again.',
        });
    }
}
exports.UnauthorizedError = UnauthorizedError;
class ForbiddenError extends AppError {
    constructor(message = 'Access denied') {
        super({
            code: ErrorCode.FORBIDDEN,
            message,
            statusCode: 403,
            recoverable: false,
            recoverySuggestion: 'You do not have permission to perform this action.',
        });
    }
}
exports.ForbiddenError = ForbiddenError;
class NotFoundError extends AppError {
    constructor(resource = 'Resource') {
        super({
            code: ErrorCode.NOT_FOUND,
            message: `${resource} not found`,
            statusCode: 404,
            recoverable: false,
            recoverySuggestion: 'Please verify the resource exists and try again.',
        });
    }
}
exports.NotFoundError = NotFoundError;
class ValidationError extends AppError {
    constructor(message, validationErrors) {
        super({
            code: ErrorCode.VALIDATION_ERROR,
            message,
            statusCode: 422,
            details: { validationErrors },
            recoverable: true,
            recoverySuggestion: 'Please correct the validation errors and resubmit.',
        });
    }
}
exports.ValidationError = ValidationError;
class ConflictError extends AppError {
    constructor(message, details) {
        super({
            code: ErrorCode.CONFLICT,
            message,
            statusCode: 409,
            details,
            recoverable: true,
            recoverySuggestion: 'The resource already exists or is in a conflicting state.',
        });
    }
}
exports.ConflictError = ConflictError;
class RateLimitError extends AppError {
    constructor(retryAfter) {
        super({
            code: ErrorCode.RATE_LIMIT_EXCEEDED,
            message: 'Rate limit exceeded',
            statusCode: 429,
            details: { retryAfter },
            recoverable: true,
            recoverySuggestion: retryAfter
                ? `Please wait ${retryAfter} seconds before trying again.`
                : 'Please wait a moment before trying again.',
        });
    }
}
exports.RateLimitError = RateLimitError;
/**
 * Server error classes (5xx)
 */
class InternalError extends AppError {
    constructor(message = 'Internal server error', details) {
        super({
            code: ErrorCode.INTERNAL_ERROR,
            message,
            statusCode: 500,
            details,
            recoverable: true,
            recoverySuggestion: 'An unexpected error occurred. Please try again later.',
        });
    }
}
exports.InternalError = InternalError;
class ServiceUnavailableError extends AppError {
    constructor(service, retryAfter) {
        super({
            code: ErrorCode.SERVICE_UNAVAILABLE,
            message: `${service} is temporarily unavailable`,
            statusCode: 503,
            details: { service, retryAfter },
            recoverable: true,
            recoverySuggestion: retryAfter
                ? `The service is temporarily unavailable. Please try again in ${retryAfter} seconds.`
                : 'The service is temporarily unavailable. Please try again shortly.',
        });
    }
}
exports.ServiceUnavailableError = ServiceUnavailableError;
class AIServiceError extends AppError {
    constructor(message = 'AI service error', details, recoverable = true) {
        super({
            code: ErrorCode.AI_SERVICE_ERROR,
            message,
            statusCode: 503,
            details,
            recoverable,
            recoverySuggestion: recoverable
                ? 'AI service encountered an error. Falling back to database recipes.'
                : 'AI service is unavailable. Please try again later.',
        });
    }
}
exports.AIServiceError = AIServiceError;
class DatabaseError extends AppError {
    constructor(message = 'Database error', details) {
        super({
            code: ErrorCode.DATABASE_ERROR,
            message,
            statusCode: 503,
            details,
            recoverable: true,
            recoverySuggestion: 'Database operation failed. Please try again.',
        });
    }
}
exports.DatabaseError = DatabaseError;
class TimeoutError extends AppError {
    constructor(operation) {
        super({
            code: ErrorCode.TIMEOUT,
            message: `${operation} timed out`,
            statusCode: 504,
            recoverable: true,
            recoverySuggestion: 'The operation took too long. Please try again.',
        });
    }
}
exports.TimeoutError = TimeoutError;
/**
 * Error response formatter for API Gateway
 */
function formatErrorResponse(error) {
    const isAppError = error instanceof AppError;
    const statusCode = isAppError ? error.statusCode : 500;
    const response = isAppError
        ? error.toJSON()
        : {
            error: {
                code: ErrorCode.INTERNAL_ERROR,
                message: 'An unexpected error occurred',
                recoverable: true,
                recoverySuggestion: 'Please try again later.',
                timestamp: new Date().toISOString(),
            },
        };
    // Log error details for monitoring
    console.error(JSON.stringify({
        timestamp: new Date().toISOString(),
        level: 'ERROR',
        error: {
            name: error.name,
            message: error.message,
            code: isAppError ? error.code : ErrorCode.INTERNAL_ERROR,
            statusCode,
            stack: error.stack,
            details: isAppError ? error.details : undefined,
        },
    }));
    return {
        statusCode,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'X-Error-Code': isAppError ? error.code : ErrorCode.INTERNAL_ERROR,
        },
        body: JSON.stringify(response),
    };
}
/**
 * Determine if error is transient and should be retried
 */
function isTransientError(error) {
    if (error instanceof AppError) {
        return error.recoverable && [
            ErrorCode.SERVICE_UNAVAILABLE,
            ErrorCode.AI_SERVICE_ERROR,
            ErrorCode.DATABASE_ERROR,
            ErrorCode.TIMEOUT,
            ErrorCode.INTERNAL_ERROR,
        ].includes(error.code);
    }
    // Common AWS SDK transient errors
    const transientErrorNames = [
        'ThrottlingException',
        'ProvisionedThroughputExceededException',
        'RequestLimitExceeded',
        'ServiceUnavailable',
        'TimeoutError',
        'NetworkingError',
    ];
    return transientErrorNames.some(name => error.name === name || error.message.includes(name));
}
/**
 * Get retry delay for transient errors (exponential backoff)
 */
function getRetryDelay(attempt, baseDelay = 1000) {
    return Math.min(baseDelay * Math.pow(2, attempt - 1), 30000); // Max 30 seconds
}
