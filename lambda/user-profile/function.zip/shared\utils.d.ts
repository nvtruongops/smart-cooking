export declare function generateUUID(): string;
export declare function normalizeText(text: string): string;
export declare function calculateSimilarity(str1: string, str2: string): number;
export declare function validateEmail(email: string): boolean;
export declare function validateAge(birthDate: string): boolean;
export declare function sanitizeInput(input: string, maxLength?: number): string;
export declare function formatTimestamp(date?: Date): string;
export declare function parseJSON(jsonString: string | null): any;
export declare function logStructured(level: 'INFO' | 'WARN' | 'ERROR', message: string, metadata?: any): void;
export declare function getUserIdFromEvent(event: any): string;
export declare function validateRating(rating: number): boolean;
export declare function calculateAverageRating(ratings: Array<{
    rating: number;
}>): number;
export declare function shouldAutoApprove(averageRating: number, minRatingCount?: number, threshold?: number): boolean;
export declare function createCacheKey(prefix: string, ...parts: string[]): string;
export declare function isValidUUID(uuid: string): boolean;
export declare function getAgeFromBirthYear(birthYear: number): number;
export declare function extractBirthYear(birthDate: string): number | null;
export declare function delay(ms: number): Promise<void>;
export interface RetryOptions {
    maxRetries?: number;
    baseDelay?: number;
    maxDelay?: number;
    shouldRetry?: (error: Error) => boolean;
    onRetry?: (error: Error, attempt: number) => void;
}
export declare function retryWithBackoff<T>(fn: () => Promise<T>, maxRetries?: number, baseDelay?: number): Promise<T>;
export declare function retryWithExponentialBackoff<T>(fn: () => Promise<T>, options?: RetryOptions): Promise<T>;
