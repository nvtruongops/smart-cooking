/**
 * Structured JSON logging utility for Lambda functions
 * Provides consistent log formatting with levels, metadata, and correlation IDs
 */
export declare enum LogLevel {
    DEBUG = "DEBUG",
    INFO = "INFO",
    WARN = "WARN",
    ERROR = "ERROR"
}
export interface LogMetadata {
    [key: string]: any;
}
export interface LogContext {
    requestId?: string;
    userId?: string;
    functionName?: string;
    functionVersion?: string;
    traceId?: string;
    [key: string]: any;
}
declare class Logger {
    private context;
    private logLevel;
    constructor();
    /**
     * Set context that will be included in all subsequent logs
     */
    setContext(context: LogContext): void;
    /**
     * Clear the logging context
     */
    clearContext(): void;
    /**
     * Get current context
     */
    getContext(): LogContext;
    /**
     * Initialize logger from Lambda event
     */
    initFromEvent(event: any): void;
    /**
     * Check if a log level should be logged
     */
    private shouldLog;
    /**
     * Core logging function
     */
    private log;
    /**
     * Log debug message
     */
    debug(message: string, metadata?: LogMetadata): void;
    /**
     * Log info message
     */
    info(message: string, metadata?: LogMetadata): void;
    /**
     * Log warning message
     */
    warn(message: string, metadata?: LogMetadata): void;
    /**
     * Log error message
     */
    error(message: string, error?: Error | any, metadata?: LogMetadata): void;
    /**
     * Log the start of a Lambda function execution
     */
    logFunctionStart(functionName: string, event: any): void;
    /**
     * Log the end of a Lambda function execution
     */
    logFunctionEnd(functionName: string, statusCode: number, duration?: number): void;
    /**
     * Log performance metrics
     */
    logPerformance(operation: string, duration: number, metadata?: LogMetadata): void;
    /**
     * Log database operation
     */
    logDatabaseOperation(operation: string, table: string, duration?: number, metadata?: LogMetadata): void;
    /**
     * Log external API call
     */
    logApiCall(service: string, operation: string, duration?: number, metadata?: LogMetadata): void;
    /**
     * Log business metric
     */
    logBusinessMetric(metric: string, value: number, unit?: string, metadata?: LogMetadata): void;
    /**
     * Log security event
     */
    logSecurityEvent(event: string, severity: 'low' | 'medium' | 'high' | 'critical', metadata?: LogMetadata): void;
}
export declare const logger: Logger;
/**
 * Helper to measure execution time
 */
export declare function measureTime<T>(operation: string, fn: () => Promise<T>, logResult?: boolean): Promise<T>;
/**
 * Helper to create a child logger with additional context
 */
export declare function createChildLogger(additionalContext: LogContext): Logger;
export {};
