/**
 * Monitoring Setup Utility
 * Ensures all Lambda functions have proper monitoring configuration
 */
export interface MonitoringConfig {
    functionName: string;
    logLevel?: 'DEBUG' | 'INFO' | 'WARN' | 'ERROR';
    enableXRay?: boolean;
    enableMetrics?: boolean;
    customDimensions?: {
        [key: string]: string;
    };
}
/**
 * Initialize monitoring for a Lambda function
 */
export declare function initializeMonitoring(config: MonitoringConfig): void;
/**
 * Wrapper for Lambda handlers with automatic monitoring
 */
export declare function withMonitoring<T extends any[], R>(functionName: string, handler: (...args: T) => Promise<R>, config?: Partial<MonitoringConfig>): (...args: T) => Promise<R>;
/**
 * Middleware for database operations with monitoring
 */
export declare function withDatabaseMonitoring<T>(operation: string, tableName: string, fn: () => Promise<T>): Promise<T>;
/**
 * Middleware for external API calls with monitoring
 */
export declare function withApiCallMonitoring<T>(service: string, operation: string, fn: () => Promise<T>, url?: string): Promise<T>;
/**
 * Helper to create CloudWatch custom metrics for business events
 */
export declare function trackBusinessEvent(eventName: string, value?: number, dimensions?: {
    [key: string]: string;
}): void;
/**
 * Helper to track user activity
 */
export declare function trackUserActivity(activityType: string, userId?: string, metadata?: {
    [key: string]: any;
}): void;
/**
 * Helper to track security events
 */
export declare function trackSecurityEvent(event: string, severity: 'low' | 'medium' | 'high' | 'critical', metadata?: {
    [key: string]: any;
}): void;
/**
 * Performance monitoring decorator
 */
export declare function performanceMonitor(operationName: string): (target: any, propertyKey: string, descriptor: PropertyDescriptor) => PropertyDescriptor;
/**
 * Cost tracking helper for AI operations
 */
export declare function trackAICost(modelId: string, inputTokens: number, outputTokens: number, duration: number, estimatedCost?: number): void;
/**
 * Validate monitoring environment variables
 */
export declare function validateMonitoringConfig(): {
    isValid: boolean;
    missingVars: string[];
    warnings: string[];
};
