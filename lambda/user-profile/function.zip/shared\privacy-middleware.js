"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkFriendship = checkFriendship;
exports.createPrivacyContext = createPrivacyContext;
exports.getUserPrivacySettings = getUserPrivacySettings;
exports.hasAccess = hasAccess;
exports.filterUserProfile = filterUserProfile;
exports.filterCookingHistory = filterCookingHistory;
exports.filterUserPreferences = filterUserPreferences;
exports.canAccessField = canAccessField;
const dynamodb_1 = require("./dynamodb");
/**
 * Check if two users are friends
 */
async function checkFriendship(userId1, userId2) {
    if (userId1 === userId2)
        return false;
    try {
        // Check for accepted friendship in either direction
        const friendship = await dynamodb_1.DynamoDBHelper.get(`USER#${userId1}`, `FRIEND#${userId2}`);
        if (friendship && friendship.status === 'accepted') {
            return true;
        }
        // Check reverse direction
        const reverseFriendship = await dynamodb_1.DynamoDBHelper.get(`USER#${userId2}`, `FRIEND#${userId1}`);
        return reverseFriendship?.status === 'accepted';
    }
    catch (error) {
        console.error('Error checking friendship:', error);
        return false;
    }
}
/**
 * Create privacy context for filtering
 */
async function createPrivacyContext(viewerId, targetUserId) {
    const isSelf = viewerId === targetUserId;
    const isFriend = isSelf ? false : await checkFriendship(viewerId, targetUserId);
    return {
        viewerId,
        targetUserId,
        isSelf,
        isFriend
    };
}
/**
 * Get user's privacy settings
 */
async function getUserPrivacySettings(userId) {
    try {
        const privacySettings = await dynamodb_1.DynamoDBHelper.get(`USER#${userId}`, 'PRIVACY');
        if (privacySettings) {
            return {
                profile_visibility: privacySettings.profile_visibility,
                email_visibility: privacySettings.email_visibility,
                date_of_birth_visibility: privacySettings.date_of_birth_visibility,
                cooking_history_visibility: privacySettings.cooking_history_visibility,
                preferences_visibility: privacySettings.preferences_visibility
            };
        }
        // Return default privacy settings
        return {
            profile_visibility: 'public',
            email_visibility: 'private',
            date_of_birth_visibility: 'private',
            cooking_history_visibility: 'public',
            preferences_visibility: 'friends'
        };
    }
    catch (error) {
        console.error('Error getting privacy settings:', error);
        // Return most restrictive defaults on error
        return {
            profile_visibility: 'private',
            email_visibility: 'private',
            date_of_birth_visibility: 'private',
            cooking_history_visibility: 'private',
            preferences_visibility: 'private'
        };
    }
}
/**
 * Check if viewer has access based on privacy level
 */
function hasAccess(privacyLevel, context) {
    // Owner always has access
    if (context.isSelf) {
        return true;
    }
    // Check privacy level
    switch (privacyLevel) {
        case 'public':
            return true;
        case 'friends':
            return context.isFriend;
        case 'private':
            return false;
        default:
            return false;
    }
}
/**
 * Filter user profile based on privacy settings
 */
async function filterUserProfile(profile, context) {
    // If viewing own profile, return everything
    if (context.isSelf) {
        return profile;
    }
    const privacySettings = await getUserPrivacySettings(context.targetUserId);
    const filteredProfile = {};
    // Always include non-sensitive fields
    filteredProfile.user_id = profile.user_id;
    filteredProfile.username = profile.username;
    // Filter based on profile_visibility
    if (hasAccess(privacySettings.profile_visibility, context)) {
        filteredProfile.full_name = profile.full_name;
        filteredProfile.avatar_url = profile.avatar_url;
        filteredProfile.gender = profile.gender;
        filteredProfile.country = profile.country;
        filteredProfile.created_at = profile.created_at;
    }
    // Filter email based on email_visibility
    if (hasAccess(privacySettings.email_visibility, context)) {
        filteredProfile.email = profile.email;
    }
    // Filter date_of_birth based on date_of_birth_visibility
    if (hasAccess(privacySettings.date_of_birth_visibility, context)) {
        filteredProfile.date_of_birth = profile.date_of_birth;
    }
    return filteredProfile;
}
/**
 * Filter cooking history based on privacy settings
 */
async function filterCookingHistory(history, context) {
    // If viewing own history, return everything
    if (context.isSelf) {
        return history;
    }
    const privacySettings = await getUserPrivacySettings(context.targetUserId);
    // Check if viewer has access to cooking history
    if (!hasAccess(privacySettings.cooking_history_visibility, context)) {
        return [];
    }
    return history;
}
/**
 * Filter user preferences based on privacy settings
 */
async function filterUserPreferences(preferences, context) {
    // If viewing own preferences, return everything
    if (context.isSelf) {
        return preferences;
    }
    const privacySettings = await getUserPrivacySettings(context.targetUserId);
    // Check if viewer has access to preferences
    if (!hasAccess(privacySettings.preferences_visibility, context)) {
        return null;
    }
    return preferences;
}
/**
 * Check if viewer can access specific data field
 */
async function canAccessField(fieldName, context) {
    if (context.isSelf) {
        return true;
    }
    const privacySettings = await getUserPrivacySettings(context.targetUserId);
    const privacyLevel = privacySettings[fieldName];
    return hasAccess(privacyLevel, context);
}
