import { PrivacySettings, PrivacyLevel } from './types';
/**
 * Privacy Filtering Middleware
 * Filters data based on user privacy settings and friendship status
 */
export interface PrivacyContext {
    viewerId: string;
    targetUserId: string;
    isSelf: boolean;
    isFriend: boolean;
}
/**
 * Check if two users are friends
 */
export declare function checkFriendship(userId1: string, userId2: string): Promise<boolean>;
/**
 * Create privacy context for filtering
 */
export declare function createPrivacyContext(viewerId: string, targetUserId: string): Promise<PrivacyContext>;
/**
 * Get user's privacy settings
 */
export declare function getUserPrivacySettings(userId: string): Promise<PrivacySettings>;
/**
 * Check if viewer has access based on privacy level
 */
export declare function hasAccess(privacyLevel: PrivacyLevel, context: PrivacyContext): boolean;
/**
 * Filter user profile based on privacy settings
 */
export declare function filterUserProfile(profile: any, context: PrivacyContext): Promise<any>;
/**
 * Filter cooking history based on privacy settings
 */
export declare function filterCookingHistory(history: any[], context: PrivacyContext): Promise<any[]>;
/**
 * Filter user preferences based on privacy settings
 */
export declare function filterUserPreferences(preferences: any, context: PrivacyContext): Promise<any | null>;
/**
 * Check if viewer can access specific data field
 */
export declare function canAccessField(fieldName: keyof PrivacySettings, context: PrivacyContext): Promise<boolean>;
