"use strict";
/**
 * AWS X-Ray distributed tracing utility for Lambda functions
 * Provides segment and subsegment creation for detailed performance monitoring
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.tracer = exports.XRayTracer = void 0;
exports.trace = trace;
exports.traceOperation = traceOperation;
exports.captureAWS = captureAWS;
const AWSXRay = __importStar(require("aws-xray-sdk-core"));
const logger_1 = require("./logger");
/**
 * X-Ray tracing wrapper class
 */
class XRayTracer {
    constructor() {
        // X-Ray is automatically enabled in Lambda when tracing is active
        this.isEnabled = !!process.env._X_AMZN_TRACE_ID;
    }
    /**
     * Create a subsegment for an operation
     */
    async captureAsyncFunc(name, fn, annotations, metadata) {
        if (!this.isEnabled) {
            // If X-Ray is not enabled, just execute the function
            return fn();
        }
        return AWSXRay.captureAsyncFunc(name, async (subsegment) => {
            try {
                // Add annotations (indexed for searching)
                if (annotations && subsegment) {
                    Object.entries(annotations).forEach(([key, value]) => {
                        subsegment.addAnnotation(key, value);
                    });
                }
                // Add metadata (not indexed, for detailed info)
                if (metadata && subsegment) {
                    Object.entries(metadata).forEach(([namespace, data]) => {
                        subsegment.addMetadata(namespace, data);
                    });
                }
                const result = await fn(subsegment);
                if (subsegment) {
                    subsegment.close();
                }
                return result;
            }
            catch (error) {
                if (subsegment) {
                    subsegment.addError(error);
                    subsegment.close(error);
                }
                throw error;
            }
        });
    }
    /**
     * Capture a database operation
     */
    async captureDatabaseOperation(operation, tableName, fn) {
        return this.captureAsyncFunc(`DynamoDB.${operation}`, fn, {
            table_name: tableName,
            operation: operation
        }, {
            database: {
                table: tableName,
                operation: operation
            }
        });
    }
    /**
     * Capture an external API call
     */
    async captureApiCall(service, operation, fn, url) {
        return this.captureAsyncFunc(`${service}.${operation}`, fn, {
            service: service,
            operation: operation
        }, {
            http: {
                service: service,
                operation: operation,
                ...(url ? { url } : {})
            }
        });
    }
    /**
     * Capture AWS SDK call (Bedrock, etc.)
     */
    async captureAwsCall(serviceName, operation, fn, metadata) {
        return this.captureAsyncFunc(`AWS.${serviceName}.${operation}`, fn, {
            aws_service: serviceName,
            aws_operation: operation
        }, {
            aws: {
                service: serviceName,
                operation: operation,
                ...metadata
            }
        });
    }
    /**
     * Capture business logic operation
     */
    async captureBusinessOperation(operationName, fn, businessData) {
        return this.captureAsyncFunc(operationName, fn, undefined, {
            business: businessData || {}
        });
    }
    /**
     * Add annotation to current segment
     */
    addAnnotation(key, value) {
        if (!this.isEnabled)
            return;
        try {
            const segment = AWSXRay.getSegment();
            if (segment) {
                segment.addAnnotation(key, value);
            }
        }
        catch (error) {
            logger_1.logger.debug('Failed to add X-Ray annotation', { key, error });
        }
    }
    /**
     * Add metadata to current segment
     */
    addMetadata(namespace, data) {
        if (!this.isEnabled)
            return;
        try {
            const segment = AWSXRay.getSegment();
            if (segment) {
                segment.addMetadata(namespace, data);
            }
        }
        catch (error) {
            logger_1.logger.debug('Failed to add X-Ray metadata', { namespace, error });
        }
    }
    /**
     * Record user information
     */
    setUser(userId) {
        if (!this.isEnabled)
            return;
        try {
            const segment = AWSXRay.getSegment();
            if (segment && 'setUser' in segment) {
                segment.setUser(userId);
                segment.addAnnotation('user_id', userId);
            }
        }
        catch (error) {
            logger_1.logger.debug('Failed to set X-Ray user', { userId, error });
        }
    }
    /**
     * Get current trace ID
     */
    getTraceId() {
        if (!this.isEnabled)
            return undefined;
        try {
            const segment = AWSXRay.getSegment();
            return segment?.trace_id;
        }
        catch (error) {
            return undefined;
        }
    }
    /**
     * Check if X-Ray is enabled
     */
    isTracingEnabled() {
        return this.isEnabled;
    }
}
exports.XRayTracer = XRayTracer;
// Export singleton instance
exports.tracer = new XRayTracer();
/**
 * Decorator to automatically trace async functions
 */
function trace(operationName, annotations) {
    return function (target, propertyKey, descriptor) {
        const originalMethod = descriptor.value;
        const traceName = operationName || `${target.constructor.name}.${propertyKey}`;
        descriptor.value = async function (...args) {
            return exports.tracer.captureAsyncFunc(traceName, () => originalMethod.apply(this, args), annotations);
        };
        return descriptor;
    };
}
/**
 * Helper to measure and trace execution time
 */
async function traceOperation(operationName, fn, annotations, metadata) {
    const start = Date.now();
    try {
        const result = await exports.tracer.captureAsyncFunc(operationName, fn, annotations, metadata);
        const duration = Date.now() - start;
        logger_1.logger.logPerformance(operationName, duration, { success: true });
        return result;
    }
    catch (error) {
        const duration = Date.now() - start;
        logger_1.logger.logPerformance(operationName, duration, { success: false });
        throw error;
    }
}
/**
 * Capture AWS SDK clients with X-Ray
 */
function captureAWS(awsService) {
    if (!process.env._X_AMZN_TRACE_ID) {
        return awsService;
    }
    try {
        return AWSXRay.captureAWSv3Client(awsService);
    }
    catch (error) {
        logger_1.logger.warn('Failed to capture AWS service with X-Ray', { error });
        return awsService;
    }
}
