"use strict";
/**
 * Graceful Degradation Utilities
 * Handles service failures with fallback mechanisms
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AIServiceWrapper = void 0;
exports.withGracefulDegradation = withGracefulDegradation;
exports.withDatabaseFallback = withDatabaseFallback;
exports.executeBatchWithPartialSuccess = executeBatchWithPartialSuccess;
exports.checkServiceHealth = checkServiceHealth;
const errors_1 = require("./errors");
const utils_1 = require("./utils");
/**
 * Execute operation with graceful degradation
 * Falls back to alternative function if primary fails
 */
async function withGracefulDegradation(primaryFn, options) {
    const { serviceName, enableFallback, fallbackFn, timeoutMs, onError } = options;
    try {
        // Execute primary function with timeout if specified
        if (timeoutMs) {
            return await executeWithTimeout(primaryFn, timeoutMs, serviceName);
        }
        return await primaryFn();
    }
    catch (error) {
        (0, utils_1.logStructured)('ERROR', `${serviceName} failed`, {
            error: error instanceof Error ? error.message : 'Unknown error',
            enableFallback,
        });
        // Call error handler if provided
        if (onError) {
            onError(error);
        }
        // Attempt fallback if enabled and available
        if (enableFallback && fallbackFn) {
            (0, utils_1.logStructured)('INFO', `Attempting fallback for ${serviceName}`);
            try {
                const fallbackResult = await fallbackFn();
                (0, utils_1.logStructured)('INFO', `Fallback successful for ${serviceName}`, {
                    fallbackUsed: true,
                });
                return fallbackResult;
            }
            catch (fallbackError) {
                (0, utils_1.logStructured)('ERROR', `Fallback failed for ${serviceName}`, {
                    error: fallbackError instanceof Error ? fallbackError.message : 'Unknown error',
                });
                throw new errors_1.ServiceUnavailableError(serviceName);
            }
        }
        // Re-throw original error if no fallback
        throw error;
    }
}
/**
 * Execute function with timeout
 */
async function executeWithTimeout(fn, timeoutMs, operationName) {
    return Promise.race([
        fn(),
        new Promise((_, reject) => setTimeout(() => reject(new errors_1.TimeoutError(operationName)), timeoutMs)),
    ]);
}
/**
 * AI Service wrapper with graceful degradation
 */
class AIServiceWrapper {
    /**
     * Execute AI service call with circuit breaker pattern
     */
    static async execute(aiFn, fallbackFn, timeoutMs = 30000) {
        // Check if circuit breaker is open
        if (this.isCircuitOpen()) {
            (0, utils_1.logStructured)('WARN', 'AI service circuit breaker is open, using fallback');
            if (fallbackFn) {
                return fallbackFn();
            }
            throw new errors_1.AIServiceError('AI service is temporarily unavailable due to repeated failures', { circuitBreakerOpen: true }, true);
        }
        try {
            const result = await executeWithTimeout(aiFn, timeoutMs, 'AI service');
            // Reset failure count on success
            this.resetFailureCount();
            return result;
        }
        catch (error) {
            this.recordFailure();
            (0, utils_1.logStructured)('ERROR', 'AI service execution failed', {
                error: error instanceof Error ? error.message : 'Unknown error',
                failureCount: this.failureCount,
                circuitBreakerOpen: this.isCircuitOpen(),
            });
            // Use fallback if available
            if (fallbackFn) {
                (0, utils_1.logStructured)('INFO', 'Using fallback for AI service failure');
                return fallbackFn();
            }
            // Determine if error is recoverable
            const recoverable = error instanceof errors_1.TimeoutError ||
                (error instanceof Error && this.isRecoverableAIError(error));
            throw new errors_1.AIServiceError(error instanceof Error ? error.message : 'AI service failed', { originalError: error }, recoverable);
        }
    }
    /**
     * Check if circuit breaker should be open
     */
    static isCircuitOpen() {
        if (this.failureCount < this.MAX_FAILURES) {
            return false;
        }
        if (!this.lastFailureTime) {
            return false;
        }
        const timeSinceLastFailure = Date.now() - this.lastFailureTime;
        // Reset if failure window has passed
        if (timeSinceLastFailure > this.FAILURE_WINDOW_MS) {
            this.resetFailureCount();
            return false;
        }
        return true;
    }
    /**
     * Record a failure
     */
    static recordFailure() {
        this.failureCount++;
        this.lastFailureTime = Date.now();
    }
    /**
     * Reset failure count
     */
    static resetFailureCount() {
        this.failureCount = 0;
        this.lastFailureTime = null;
    }
    /**
     * Determine if AI error is recoverable
     */
    static isRecoverableAIError(error) {
        const recoverablePatterns = [
            'ThrottlingException',
            'ModelTimeoutException',
            'ServiceUnavailableException',
            'TooManyRequestsException',
            'InternalServerException',
        ];
        return recoverablePatterns.some(pattern => error.name.includes(pattern) || error.message.includes(pattern));
    }
}
exports.AIServiceWrapper = AIServiceWrapper;
AIServiceWrapper.failureCount = 0;
AIServiceWrapper.lastFailureTime = null;
AIServiceWrapper.MAX_FAILURES = 3;
AIServiceWrapper.FAILURE_WINDOW_MS = 60000; // 1 minute
/**
 * Database operation wrapper with graceful degradation
 */
async function withDatabaseFallback(operation, fallbackValue) {
    try {
        return await operation();
    }
    catch (error) {
        (0, utils_1.logStructured)('ERROR', 'Database operation failed', {
            error: error instanceof Error ? error.message : 'Unknown error',
            hasFallback: fallbackValue !== undefined,
        });
        if (fallbackValue !== undefined) {
            (0, utils_1.logStructured)('INFO', 'Using fallback value for database operation');
            return fallbackValue;
        }
        throw error;
    }
}
async function executeBatchWithPartialSuccess(items, processFn) {
    const results = await Promise.allSettled(items.map(item => processFn(item)));
    const successful = [];
    const failed = [];
    results.forEach((result, index) => {
        if (result.status === 'fulfilled') {
            successful.push(result.value);
        }
        else {
            failed.push({
                item: items[index],
                error: result.reason,
            });
        }
    });
    const partialSuccess = successful.length > 0 && failed.length > 0;
    (0, utils_1.logStructured)('INFO', 'Batch operation completed', {
        total: items.length,
        successful: successful.length,
        failed: failed.length,
        partialSuccess,
    });
    return { successful, failed, partialSuccess };
}
async function checkServiceHealth(serviceName, healthCheckFn, timeoutMs = 5000) {
    const startTime = Date.now();
    try {
        await executeWithTimeout(healthCheckFn, timeoutMs, `${serviceName} health check`);
        return {
            service: serviceName,
            healthy: true,
            responseTimeMs: Date.now() - startTime,
        };
    }
    catch (error) {
        return {
            service: serviceName,
            healthy: false,
            message: error instanceof Error ? error.message : 'Health check failed',
            responseTimeMs: Date.now() - startTime,
        };
    }
}
