/**
 * Social Features Query Optimizations
 * Task 18.2: Optimize social queries and performance
 *
 * Implements:
 * - Feed query optimization with GSI3
 * - Friend list caching
 * - Pagination for posts, comments, and notifications
 * - Sparse index optimization for unread notifications
 * - DynamoDB read/write cost reduction
 *
 * Requirements: 7.1, 9.2
 */
export interface PaginationOptions {
    limit?: number;
    nextToken?: string;
}
export interface PaginatedResponse<T> {
    items: T[];
    nextToken?: string;
    count: number;
}
/**
 * Social Features Optimization Service
 */
export declare class SocialOptimizations {
    private client;
    private tableName;
    private cache;
    private metrics;
    constructor();
    /**
     * Optimized feed query using GSI3 with efficient pagination
     * Combines public posts and friends' posts in a single query
     */
    getFeedOptimized(userId: string, options?: PaginationOptions): Promise<PaginatedResponse<any>>;
    /**
     * Query feed by GSI3 key with pagination
     */
    private queryFeedByKey;
    /**
     * Get cached friend list to reduce DynamoDB reads
     * Cache TTL: 15 minutes
     */
    getCachedFriendList(userId: string): Promise<string[]>;
    /**
     * Invalidate friend list cache when friendship changes
     */
    invalidateFriendCache(userId: string, friendId: string): Promise<void>;
    /**
     * Optimized unread notifications query using sparse GSI1 index
     * Only queries items with GSI1PK = USER#<id>#UNREAD
     */
    getUnreadNotifications(userId: string, options?: PaginationOptions): Promise<PaginatedResponse<any>>;
    /**
     * Paginated post comments query
     */
    getPostComments(postId: string, options?: PaginationOptions): Promise<PaginatedResponse<any>>;
    /**
     * Paginated user posts query with privacy filtering
     */
    getUserPosts(userId: string, requestingUserId: string, options?: PaginationOptions): Promise<PaginatedResponse<any>>;
    /**
     * Batch get posts for feed with reduced read units
     */
    batchGetPosts(postIds: string[]): Promise<any[]>;
    /**
     * Encode pagination token
     */
    private encodeNextToken;
    /**
     * Decode pagination token
     */
    private decodeNextToken;
    /**
     * Get social features performance statistics
     */
    getPerformanceStats(): Promise<{
        cacheHitRate: number;
        avgQueryTime: number;
        totalQueries: number;
        costSavings: number;
    }>;
}
export declare function getSocialOptimizations(): SocialOptimizations;
export declare const SOCIAL_CACHE_TTL: {
    readonly FRIEND_LIST: number;
    readonly USER_POSTS: number;
    readonly FEED: number;
    readonly NOTIFICATIONS: number;
};
