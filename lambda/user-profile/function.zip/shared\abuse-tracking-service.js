"use strict";
/**
 * User Abuse Tracking Service
 *
 * Tracks user violations and enforces progressive penalties:
 * - Warning 1-2: Soft warning
 * - Warning 3-4: Strong warning
 * - Warning 5+: Report to admin dashboard
 * - Weekly reset: Violations reset after 7 days
 *
 * Storage: DynamoDB with TTL for auto-cleanup
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AbuseTrackingService = void 0;
const dynamodb_1 = require("../shared/dynamodb");
const logger_1 = require("../shared/logger");
const uuid_1 = require("uuid");
class AbuseTrackingService {
    /**
     * Get current week key (YYYY-WW format)
     */
    static getCurrentWeekKey() {
        const now = new Date();
        const year = now.getFullYear();
        // Calculate week number (ISO 8601)
        const startOfYear = new Date(year, 0, 1);
        const days = Math.floor((now.getTime() - startOfYear.getTime()) / (24 * 60 * 60 * 1000));
        const weekNumber = Math.ceil((days + startOfYear.getDay() + 1) / 7);
        return `${year}-${String(weekNumber).padStart(2, '0')}`;
    }
    /**
     * Record a violation
     */
    static async recordViolation(userId, violationType, severity, evidence) {
        const timestamp = new Date().toISOString();
        const weekKey = this.getCurrentWeekKey();
        const violationId = (0, uuid_1.v4)();
        // Calculate TTL (30 days from now)
        const ttl = Math.floor(Date.now() / 1000) + (this.RECORD_TTL_DAYS * 24 * 60 * 60);
        // Save violation record
        await dynamodb_1.DynamoDBHelper.put({
            PK: `USER#${userId}`,
            SK: `VIOLATION#${timestamp}#${violationId}`,
            entity_type: 'abuse_violation',
            user_id: userId,
            violation_id: violationId,
            violation_type: violationType,
            severity: severity,
            evidence: evidence,
            timestamp: timestamp,
            week_key: weekKey,
            ttl: ttl, // Auto-delete after 30 days
            // GSI for admin dashboard
            GSI1PK: `VIOLATIONS#${weekKey}`,
            GSI1SK: timestamp,
            // GSI2 for severity-based queries
            GSI2PK: `SEVERITY#${severity}`,
            GSI2SK: timestamp,
        });
        logger_1.logger.warn('Violation recorded', {
            userId,
            violationType,
            severity,
            weekKey,
            violationId,
        });
        // Get updated abuse stats
        const stats = await this.getAbuseStats(userId);
        // Check if should notify admin
        if (stats.should_notify_admin) {
            await this.notifyAdmin(userId, stats);
        }
        // Check if should auto-suspend
        if (stats.this_week_violations >= this.AUTO_SUSPEND_THRESHOLD) {
            await this.autoSuspendUser(userId, stats);
        }
        return stats;
    }
    /**
     * Get abuse statistics for a user
     */
    static async getAbuseStats(userId) {
        const weekKey = this.getCurrentWeekKey();
        // Get all violations for this user
        const allViolationsResult = await dynamodb_1.DynamoDBHelper.query({
            KeyConditionExpression: 'PK = :pk AND begins_with(SK, :sk)',
            ExpressionAttributeValues: {
                ':pk': `USER#${userId}`,
                ':sk': 'VIOLATION#',
            },
        });
        const allViolations = allViolationsResult.Items || [];
        // Filter violations for this week
        const thisWeekViolations = allViolations.filter((v) => v.week_key === weekKey);
        // Calculate severity breakdown
        const severityBreakdown = {
            low: 0,
            medium: 0,
            high: 0,
            critical: 0,
        };
        thisWeekViolations.forEach((v) => {
            severityBreakdown[v.severity]++;
        });
        // Determine penalty level
        let penaltyLevel = 'none';
        const weekCount = thisWeekViolations.length;
        if (weekCount >= this.AUTO_SUSPEND_THRESHOLD) {
            penaltyLevel = 'suspended';
        }
        else if (weekCount >= this.ADMIN_NOTIFICATION_THRESHOLD) {
            penaltyLevel = 'restricted';
        }
        else if (weekCount >= 3) {
            penaltyLevel = 'warning';
        }
        return {
            total_violations: allViolations.length,
            this_week_violations: weekCount,
            last_violation: allViolations[0]?.timestamp || '',
            severity_breakdown: severityBreakdown,
            should_notify_admin: weekCount >= this.ADMIN_NOTIFICATION_THRESHOLD && weekCount < this.AUTO_SUSPEND_THRESHOLD,
            penalty_level: penaltyLevel,
        };
    }
    /**
     * Notify admin dashboard about user violations
     */
    static async notifyAdmin(userId, stats) {
        const notificationId = (0, uuid_1.v4)();
        const timestamp = new Date().toISOString();
        const weekKey = this.getCurrentWeekKey();
        // Check if already notified this week
        const existingNotification = await dynamodb_1.DynamoDBHelper.query({
            KeyConditionExpression: 'PK = :pk AND begins_with(SK, :sk)',
            ExpressionAttributeValues: {
                ':pk': 'ADMIN_NOTIFICATIONS',
                ':sk': `ABUSE#${weekKey}#${userId}`,
            },
            Limit: 1,
        });
        if (existingNotification.Items && existingNotification.Items.length > 0) {
            logger_1.logger.info('Admin already notified this week', { userId, weekKey });
            return; // Already notified
        }
        // Get violation details
        const violationsResult = await dynamodb_1.DynamoDBHelper.query({
            KeyConditionExpression: 'PK = :pk AND begins_with(SK, :sk)',
            ExpressionAttributeValues: {
                ':pk': `USER#${userId}`,
                ':sk': 'VIOLATION#',
            },
        });
        const violations = violationsResult.Items || [];
        const thisWeekViolations = violations.filter((v) => v.week_key === weekKey);
        // Create admin notification
        await dynamodb_1.DynamoDBHelper.put({
            PK: 'ADMIN_NOTIFICATIONS',
            SK: `ABUSE#${weekKey}#${userId}#${notificationId}`,
            entity_type: 'admin_notification',
            notification_id: notificationId,
            notification_type: 'user_abuse',
            user_id: userId,
            week_key: weekKey,
            violation_count: stats.this_week_violations,
            violations: thisWeekViolations.map((v) => ({
                type: v.violation_type,
                severity: v.severity,
                timestamp: v.timestamp,
            })),
            severity_breakdown: stats.severity_breakdown,
            status: 'pending',
            created_at: timestamp,
            // GSI for admin dashboard
            GSI1PK: 'PENDING_ADMIN_NOTIFICATIONS',
            GSI1SK: timestamp,
            // GSI2 for priority sorting
            GSI2PK: `PRIORITY#${stats.this_week_violations >= 10 ? 'critical' : 'high'}`,
            GSI2SK: timestamp,
        });
        logger_1.logger.warn('🚨 ADMIN NOTIFIED: User exceeded violation threshold', {
            userId,
            weekKey,
            violationCount: stats.this_week_violations,
            notificationId,
        });
        // TODO: Send email/SNS to admin team
        // await this.sendAdminEmail(userId, stats);
    }
    /**
     * Auto-suspend user account
     */
    static async autoSuspendUser(userId, stats) {
        const timestamp = new Date().toISOString();
        const weekKey = this.getCurrentWeekKey();
        // Update user status
        await dynamodb_1.DynamoDBHelper.update(`USER#${userId}`, 'PROFILE', 'SET account_status = :status, suspended_at = :now, suspension_reason = :reason', {
            ':status': 'suspended',
            ':now': timestamp,
            ':reason': `Auto-suspended: ${stats.this_week_violations} violations in week ${weekKey}`,
        });
        logger_1.logger.error('🚫 AUTO-SUSPEND: User account suspended', {
            userId,
            weekKey,
            violationCount: stats.this_week_violations,
        });
        // Create suspension record
        await dynamodb_1.DynamoDBHelper.put({
            PK: `USER#${userId}`,
            SK: `SUSPENSION#${timestamp}`,
            entity_type: 'account_suspension',
            user_id: userId,
            suspended_at: timestamp,
            suspension_type: 'auto',
            reason: `${stats.this_week_violations} violations in one week`,
            week_key: weekKey,
            violations: stats,
        });
        // Escalate to admin
        await this.escalateToAdmin(userId, stats, 'auto_suspension');
    }
    /**
     * Escalate critical case to admin
     */
    static async escalateToAdmin(userId, stats, escalationType) {
        const escalationId = (0, uuid_1.v4)();
        const timestamp = new Date().toISOString();
        await dynamodb_1.DynamoDBHelper.put({
            PK: 'ADMIN_ESCALATIONS',
            SK: `${timestamp}#${escalationId}`,
            entity_type: 'admin_escalation',
            escalation_id: escalationId,
            escalation_type: escalationType,
            user_id: userId,
            stats: stats,
            created_at: timestamp,
            status: 'urgent',
            // GSI for admin dashboard - CRITICAL priority
            GSI1PK: 'URGENT_ESCALATIONS',
            GSI1SK: timestamp,
        });
        logger_1.logger.error('🚨🚨🚨 CRITICAL ESCALATION TO ADMIN', {
            userId,
            escalationType,
            violationCount: stats.this_week_violations,
        });
    }
    /**
     * Get violations for current week (for admin dashboard)
     */
    static async getWeeklyViolations(weekKey) {
        const targetWeek = weekKey || this.getCurrentWeekKey();
        const result = await dynamodb_1.DynamoDBHelper.query({
            IndexName: 'GSI1',
            KeyConditionExpression: 'GSI1PK = :pk',
            ExpressionAttributeValues: {
                ':pk': `VIOLATIONS#${targetWeek}`,
            },
            ScanIndexForward: false, // Most recent first
        });
        return result.Items || [];
    }
    /**
     * Get pending admin notifications
     */
    static async getPendingAdminNotifications() {
        const result = await dynamodb_1.DynamoDBHelper.query({
            IndexName: 'GSI1',
            KeyConditionExpression: 'GSI1PK = :pk',
            ExpressionAttributeValues: {
                ':pk': 'PENDING_ADMIN_NOTIFICATIONS',
            },
            ScanIndexForward: false,
            Limit: 50,
        });
        return result.Items || [];
    }
    /**
     * Check if user is currently suspended
     */
    static async isUserSuspended(userId) {
        const profile = await dynamodb_1.DynamoDBHelper.get(`USER#${userId}`, 'PROFILE');
        return profile?.account_status === 'suspended';
    }
    /**
     * Get violation history for a user (for admin review)
     */
    static async getUserViolationHistory(userId, limit = 50) {
        const result = await dynamodb_1.DynamoDBHelper.query({
            KeyConditionExpression: 'PK = :pk AND begins_with(SK, :sk)',
            ExpressionAttributeValues: {
                ':pk': `USER#${userId}`,
                ':sk': 'VIOLATION#',
            },
            Limit: limit,
            ScanIndexForward: false,
        });
        return result.Items || [];
    }
    /**
     * Weekly cleanup job (can be Lambda cron)
     * Note: Records auto-delete via TTL after 30 days
     * This is just for reporting/analytics
     */
    static async weeklyCleanupReport() {
        const currentWeek = this.getCurrentWeekKey();
        const violations = await this.getWeeklyViolations(currentWeek);
        // Group by user
        const userViolations = violations.reduce((acc, v) => {
            if (!acc[v.user_id]) {
                acc[v.user_id] = [];
            }
            acc[v.user_id].push(v);
            return acc;
        }, {});
        const report = {
            week: currentWeek,
            total_violations: violations.length,
            unique_users: Object.keys(userViolations).length,
            severity_breakdown: {
                low: violations.filter((v) => v.severity === 'low').length,
                medium: violations.filter((v) => v.severity === 'medium').length,
                high: violations.filter((v) => v.severity === 'high').length,
                critical: violations.filter((v) => v.severity === 'critical').length,
            },
            users_suspended: violations.filter((v) => userViolations[v.user_id]?.length >= this.AUTO_SUSPEND_THRESHOLD).length,
        };
        logger_1.logger.info('Weekly abuse report', report);
        return report;
    }
}
exports.AbuseTrackingService = AbuseTrackingService;
// Thresholds
AbuseTrackingService.ADMIN_NOTIFICATION_THRESHOLD = 5; // Report after 5 violations in a week
AbuseTrackingService.AUTO_SUSPEND_THRESHOLD = 10; // Auto-suspend after 10 violations
AbuseTrackingService.WEEK_RESET_DAYS = 7; // Reset count after 7 days
// TTL for abuse records (30 days for historical tracking)
AbuseTrackingService.RECORD_TTL_DAYS = 30;
