/**
 * CloudWatch custom metrics utility for Lambda functions
 * Tracks business metrics, AI usage, costs, and performance
 */
import { StandardUnit } from '@aws-sdk/client-cloudwatch';
export interface MetricData {
    metricName: string;
    value: number;
    unit?: StandardUnit;
    dimensions?: {
        [key: string]: string;
    };
    timestamp?: Date;
}
export declare class MetricsPublisher {
    private namespace;
    private defaultDimensions;
    private metricsBuffer;
    private readonly MAX_BUFFER_SIZE;
    constructor(namespace?: string, defaultDimensions?: {
        [key: string]: string;
    });
    /**
     * Add a metric to the buffer
     */
    addMetric(data: MetricData): void;
    /**
     * Publish all buffered metrics to CloudWatch
     */
    flush(): Promise<void>;
    /**
     * Publish a single metric immediately
     */
    publishMetric(data: MetricData): Promise<void>;
    /**
     * Track API request
     */
    trackApiRequest(statusCode: number, duration: number, endpoint?: string): void;
    /**
     * Track AI model usage
     */
    trackAiUsage(modelId: string, inputTokens: number, outputTokens: number, duration: number, cost?: number): void;
    /**
     * Track database operation
     */
    trackDatabaseOperation(operation: string, duration: number, success: boolean, itemCount?: number): void;
    /**
     * Track cache hit/miss
     */
    trackCacheOperation(hit: boolean, cacheType?: string): void;
    /**
     * Track business metric: Recipe suggestion
     */
    trackRecipeSuggestion(fromDatabase: number, fromAi: number, ingredientCount: number): void;
    /**
     * Track cooking session
     */
    trackCookingSession(status: 'started' | 'completed', recipeSource: 'database' | 'ai'): void;
    /**
     * Track recipe rating
     */
    trackRecipeRating(rating: number, recipeSource: 'database' | 'ai', isVerifiedCook: boolean): void;
    /**
     * Track recipe auto-approval
     */
    trackRecipeAutoApproval(approved: boolean, averageRating: number, ratingCount: number): void;
    /**
     * Track ingredient validation
     */
    trackIngredientValidation(totalIngredients: number, validIngredients: number, invalidIngredients: number): void;
    /**
     * Track user activity
     */
    trackUserActivity(activityType: string, userId?: string): void;
    /**
     * Track error occurrence
     */
    trackError(operation: string, errorType: string, statusCode: number): void;
    /**
     * Track fallback usage
     */
    trackFallbackUsage(operation: string, successful: boolean): void;
    /**
     * Track retry attempts
     */
    trackRetryAttempt(operation: string, attempt: number, successful: boolean): void;
    /**
     * Track circuit breaker state changes
     */
    trackCircuitBreakerState(serviceName: string, state: 'OPEN' | 'CLOSED' | 'HALF_OPEN', failureCount: number): void;
    /**
     * Track timeout occurrences
     */
    trackTimeout(operation: string, timeoutMs: number, actualDuration: number): void;
    /**
     * Track service health
     */
    trackServiceHealth(serviceName: string, healthy: boolean, responseTime?: number): void;
}
export declare const metrics: MetricsPublisher;
/**
 * Helper to track operation with automatic metrics
 */
export declare function trackOperation<T>(operationName: string, operation: () => Promise<T>, operationType?: 'api' | 'database' | 'ai'): Promise<T>;
