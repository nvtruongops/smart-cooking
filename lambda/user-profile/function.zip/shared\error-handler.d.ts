/**
 * Centralized Error Handler
 * Implements comprehensive error handling with proper HTTP status codes,
 * graceful degradation, retry logic, and user-friendly error messages
 */
import { APIResponse } from './types';
import { AppError } from './errors';
import { RetryOptions } from './utils';
export interface ErrorHandlerOptions {
    operation: string;
    userId?: string;
    requestId?: string;
    enableFallback?: boolean;
    fallbackFn?: () => Promise<any>;
    enableRetry?: boolean;
    retryOptions?: RetryOptions;
}
/**
 * Main error handler that processes all Lambda function errors
 */
export declare class ErrorHandler {
    /**
     * Handle and format errors for API Gateway response
     */
    static handleError(error: Error | AppError, options: ErrorHandlerOptions): APIResponse;
    /**
     * Execute operation with comprehensive error handling
     */
    static executeWithErrorHandling<T>(operation: () => Promise<T>, options: ErrorHandlerOptions): Promise<T>;
    /**
     * Execute operation with retry logic and exponential backoff
     */
    private static executeWithRetry;
    /**
     * Execute fallback with proper error handling
     */
    private static executeWithFallback;
    /**
     * Create user-friendly error messages with recovery suggestions
     */
    static createUserFriendlyError(error: Error, context?: string): AppError;
    /**
     * Validate request and throw appropriate errors
     */
    static validateRequest(body: string | null, requiredFields?: string[]): any;
    /**
     * Extract user ID from event with proper error handling
     */
    static extractUserId(event: any): string;
    /**
     * Handle AI service failures with graceful degradation
     */
    static handleAIServiceFailure<T>(aiOperation: () => Promise<T>, fallbackOperation: () => Promise<T>, context: string): Promise<T>;
    /**
     * Handle database operation failures with retry
     */
    static handleDatabaseOperation<T>(operation: () => Promise<T>, operationName: string, retryCount?: number): Promise<T>;
    /**
     * Create timeout wrapper for operations
     */
    static withTimeout<T>(operation: () => Promise<T>, timeoutMs: number, operationName: string): Promise<T>;
    /**
     * Handle batch operations with partial success
     */
    static handleBatchOperation<TInput, TOutput>(items: TInput[], operation: (item: TInput) => Promise<TOutput>, operationName: string): Promise<{
        successful: TOutput[];
        failed: Array<{
            item: TInput;
            error: Error;
        }>;
        partialSuccess: boolean;
    }>;
}
/**
 * Decorator for Lambda handlers to add comprehensive error handling
 */
export declare function withErrorHandling(options?: Partial<ErrorHandlerOptions>): (target: any, propertyName: string, descriptor: PropertyDescriptor) => PropertyDescriptor;
/**
 * Circuit breaker implementation for external services
 */
export declare class CircuitBreaker {
    private readonly serviceName;
    private readonly failureThreshold;
    private readonly recoveryTimeoutMs;
    private failureCount;
    private lastFailureTime;
    private state;
    constructor(serviceName: string, failureThreshold?: number, recoveryTimeoutMs?: number);
    execute<T>(operation: () => Promise<T>): Promise<T>;
    private shouldAttemptReset;
    private onSuccess;
    private onFailure;
    getState(): string;
    getFailureCount(): number;
}
