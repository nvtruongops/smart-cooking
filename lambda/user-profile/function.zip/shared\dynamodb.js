"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TABLE_NAME = exports.ddb = exports.DynamoDBHelper = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const logger_1 = require("./logger");
const metrics_1 = require("./metrics");
const utils_1 = require("./utils");
const errors_1 = require("./errors");
// Initialize DynamoDB client
const client = new client_dynamodb_1.DynamoDBClient({
    region: process.env.AWS_REGION || 'us-east-1',
});
const ddb = lib_dynamodb_1.DynamoDBDocumentClient.from(client, {
    marshallOptions: {
        convertEmptyValues: false,
        removeUndefinedValues: true,
        convertClassInstanceToMap: false,
    },
    unmarshallOptions: {
        wrapNumbers: false,
    },
});
exports.ddb = ddb;
const TABLE_NAME = process.env.DYNAMODB_TABLE || 'smart-cooking-data';
exports.TABLE_NAME = TABLE_NAME;
class DynamoDBHelper {
    static async get(PK, SK) {
        return await this.executeWithRetry(async () => {
            const command = new lib_dynamodb_1.GetCommand({
                TableName: TABLE_NAME,
                Key: { PK, SK },
            });
            const result = await ddb.send(command);
            return result.Item;
        }, 'get', { PK, SK });
    }
    static async put(item) {
        return await this.executeWithRetry(async () => {
            const command = new lib_dynamodb_1.PutCommand({
                TableName: TABLE_NAME,
                Item: item,
            });
            return await ddb.send(command);
        }, 'put', { itemKeys: { PK: item.PK, SK: item.SK } });
    }
    static async update(PK, SK, updateExpression, expressionAttributeValues, expressionAttributeNames) {
        return await this.executeWithRetry(async () => {
            const command = new lib_dynamodb_1.UpdateCommand({
                TableName: TABLE_NAME,
                Key: { PK, SK },
                UpdateExpression: updateExpression,
                ExpressionAttributeValues: expressionAttributeValues,
                ExpressionAttributeNames: expressionAttributeNames,
                ReturnValues: 'ALL_NEW',
            });
            const result = await ddb.send(command);
            return result.Attributes;
        }, 'update', { PK, SK });
    }
    static async delete(PK, SK) {
        const command = new lib_dynamodb_1.DeleteCommand({
            TableName: TABLE_NAME,
            Key: { PK, SK },
        });
        return await ddb.send(command);
    }
    static async query(params) {
        return await this.executeWithRetry(async () => {
            const command = new lib_dynamodb_1.QueryCommand({
                TableName: TABLE_NAME,
                ...params,
            });
            const result = await ddb.send(command);
            return {
                Items: result.Items || [],
                LastEvaluatedKey: result.LastEvaluatedKey,
                Count: result.Count || 0,
            };
        }, 'query', { indexName: params.IndexName, limit: params.Limit });
    }
    static async scan(params = {}) {
        const command = new lib_dynamodb_1.ScanCommand({
            TableName: TABLE_NAME,
            ...params,
        });
        const result = await ddb.send(command);
        return {
            Items: result.Items || [],
            LastEvaluatedKey: result.LastEvaluatedKey,
            Count: result.Count || 0,
        };
    }
    static async batchGet(keys) {
        const command = new lib_dynamodb_1.BatchGetCommand({
            RequestItems: {
                [TABLE_NAME]: {
                    Keys: keys,
                },
            },
        });
        const result = await ddb.send(command);
        return result.Responses?.[TABLE_NAME] || [];
    }
    static async batchWrite(items) {
        const command = new lib_dynamodb_1.BatchWriteCommand({
            RequestItems: {
                [TABLE_NAME]: items,
            },
        });
        return await ddb.send(command);
    }
    // Helper methods for common patterns
    static async getUserProfile(userId) {
        return await this.get(`USER#${userId}`, 'PROFILE');
    }
    static async getUserPreferences(userId) {
        return await this.get(`USER#${userId}`, 'PREFERENCES');
    }
    static async getUserIngredients(userId) {
        return await this.query({
            KeyConditionExpression: 'PK = :pk AND begins_with(SK, :sk)',
            ExpressionAttributeValues: {
                ':pk': `USER#${userId}`,
                ':sk': 'INGREDIENT#',
            },
            ScanIndexForward: false, // Most recent first
        });
    }
    static async getRecipe(recipeId) {
        return await this.get(`RECIPE#${recipeId}`, 'METADATA');
    }
    static async getRecipeIngredients(recipeId) {
        return await this.query({
            KeyConditionExpression: 'PK = :pk AND begins_with(SK, :sk)',
            ExpressionAttributeValues: {
                ':pk': `RECIPE#${recipeId}`,
                ':sk': 'INGREDIENT#',
            },
        });
    }
    static async getCookingHistory(userId, favoritesOnly = false) {
        const params = {
            KeyConditionExpression: 'PK = :pk AND begins_with(SK, :sk)',
            ExpressionAttributeValues: {
                ':pk': `USER#${userId}`,
                ':sk': 'COOKING#',
            },
            ScanIndexForward: false, // Most recent first
        };
        if (favoritesOnly) {
            params.IndexName = 'GSI1';
            params.KeyConditionExpression = 'GSI1PK = :gsi1pk';
            params.ExpressionAttributeValues = {
                ':gsi1pk': `USER#${userId}#FAVORITE`,
            };
        }
        return await this.query(params);
    }
    static async getRecipeRatings(recipeId) {
        return await this.query({
            KeyConditionExpression: 'PK = :pk AND begins_with(SK, :sk)',
            ExpressionAttributeValues: {
                ':pk': `RECIPE#${recipeId}`,
                ':sk': 'RATING#',
            },
        });
    }
    static async searchIngredients(searchTerm, limit = 10) {
        return await this.query({
            IndexName: 'GSI2',
            KeyConditionExpression: 'GSI2PK = :pk AND begins_with(GSI2SK, :sk)',
            ExpressionAttributeValues: {
                ':pk': 'INGREDIENT#SEARCH',
                ':sk': `NAME#${searchTerm.toLowerCase()}`,
            },
            Limit: limit,
        });
    }
    static async searchRecipesByMethod(cookingMethod, limit = 10) {
        return await this.query({
            IndexName: 'GSI2',
            KeyConditionExpression: 'GSI2PK = :pk',
            FilterExpression: 'is_approved = :approved',
            ExpressionAttributeValues: {
                ':pk': `METHOD#${cookingMethod}`,
                ':approved': true,
            },
            Limit: limit,
            ScanIndexForward: false, // Highest rated first
        });
    }
    /**
     * Execute DynamoDB operation with retry logic and error handling
     */
    static async executeWithRetry(operation, operationName, metadata = {}) {
        const startTime = Date.now();
        try {
            const result = await (0, utils_1.retryWithExponentialBackoff)(operation, {
                maxRetries: 3,
                baseDelay: 100,
                maxDelay: 5000,
                shouldRetry: (error) => {
                    // Retry on transient DynamoDB errors
                    return (0, errors_1.isTransientError)(error) ||
                        error.name === 'ThrottlingException' ||
                        error.name === 'ProvisionedThroughputExceededException' ||
                        error.name === 'RequestLimitExceeded' ||
                        error.name === 'ServiceUnavailable';
                },
                onRetry: (error, attempt) => {
                    logger_1.logger.warn(`DynamoDB ${operationName} retry attempt ${attempt}`, {
                        error: error.message,
                        attempt,
                        operationName,
                        metadata
                    });
                    // Track retry metrics
                    metrics_1.metrics.trackRetryAttempt(operationName, attempt, false);
                }
            });
            // Track successful operation
            const duration = Date.now() - startTime;
            metrics_1.metrics.trackDatabaseOperation(operationName, duration, true);
            logger_1.logger.debug(`DynamoDB ${operationName} completed successfully`, {
                operationName,
                duration,
                metadata
            });
            return result;
        }
        catch (error) {
            const duration = Date.now() - startTime;
            // Track failed operation
            metrics_1.metrics.trackDatabaseOperation(operationName, duration, false);
            logger_1.logger.error(`DynamoDB ${operationName} failed after retries`, error, {
                operationName,
                duration,
                metadata
            });
            // Convert to DatabaseError with user-friendly message
            if (error instanceof Error) {
                if (error.name === 'ValidationException') {
                    throw new errors_1.DatabaseError('Invalid data provided to database operation', {
                        originalError: error.message,
                        operation: operationName
                    });
                }
                if (error.name === 'ResourceNotFoundException') {
                    throw new errors_1.DatabaseError('Requested resource not found', {
                        originalError: error.message,
                        operation: operationName
                    });
                }
                if (error.name === 'ConditionalCheckFailedException') {
                    throw new errors_1.DatabaseError('Operation failed due to data conflict', {
                        originalError: error.message,
                        operation: operationName
                    });
                }
                if (error.name === 'ThrottlingException' || error.name === 'ProvisionedThroughputExceededException') {
                    throw new errors_1.DatabaseError('Database is temporarily overloaded. Please try again.', {
                        originalError: error.message,
                        operation: operationName,
                        retryAfter: 30
                    });
                }
                // Generic database error
                throw new errors_1.DatabaseError(`Database operation ${operationName} failed`, {
                    originalError: error.message,
                    operation: operationName
                });
            }
            throw error;
        }
    }
}
exports.DynamoDBHelper = DynamoDBHelper;
