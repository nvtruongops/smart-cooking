"use strict";
/**
 * Centralized Error Handler
 * Implements comprehensive error handling with proper HTTP status codes,
 * graceful degradation, retry logic, and user-friendly error messages
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.CircuitBreaker = exports.ErrorHandler = void 0;
exports.withErrorHandling = withErrorHandling;
const logger_1 = require("./logger");
const metrics_1 = require("./metrics");
const errors_1 = require("./errors");
const utils_1 = require("./utils");
/**
 * Main error handler that processes all Lambda function errors
 */
class ErrorHandler {
    /**
     * Handle and format errors for API Gateway response
     */
    static handleError(error, options) {
        const { operation, userId, requestId } = options;
        // Log error with context
        logger_1.logger.error(`Error in ${operation}`, error, {
            userId,
            requestId,
            operation,
            errorType: error.constructor.name,
            recoverable: error instanceof errors_1.AppError ? error.recoverable : false
        });
        // Track error metrics
        const statusCode = error instanceof errors_1.AppError ? error.statusCode : 500;
        metrics_1.metrics.trackError(operation, error.constructor.name, statusCode);
        // Format and return error response
        return (0, errors_1.formatErrorResponse)(error);
    }
    /**
     * Execute operation with comprehensive error handling
     */
    static async executeWithErrorHandling(operation, options) {
        const { enableRetry = false, retryOptions, enableFallback = false, fallbackFn } = options;
        try {
            // Execute with retry if enabled
            if (enableRetry) {
                return await this.executeWithRetry(operation, retryOptions);
            }
            return await operation();
        }
        catch (error) {
            // Handle graceful degradation
            if (enableFallback && fallbackFn) {
                return await this.executeWithFallback(error, fallbackFn, options);
            }
            throw error;
        }
    }
    /**
     * Execute operation with retry logic and exponential backoff
     */
    static async executeWithRetry(operation, retryOptions) {
        const defaultOptions = {
            maxRetries: 3,
            baseDelay: 1000,
            maxDelay: 30000,
            shouldRetry: (error) => (0, errors_1.isTransientError)(error),
            onRetry: (error, attempt) => {
                logger_1.logger.warn(`Retrying operation (attempt ${attempt})`, {
                    error: error.message,
                    attempt,
                    errorType: error.constructor.name
                });
            }
        };
        const options = { ...defaultOptions, ...retryOptions };
        return await (0, utils_1.retryWithExponentialBackoff)(operation, options);
    }
    /**
     * Execute fallback with proper error handling
     */
    static async executeWithFallback(originalError, fallbackFn, options) {
        logger_1.logger.warn(`Primary operation failed, attempting fallback`, {
            operation: options.operation,
            originalError: originalError.message,
            userId: options.userId
        });
        try {
            const result = await fallbackFn();
            logger_1.logger.info(`Fallback successful for ${options.operation}`, {
                operation: options.operation,
                userId: options.userId,
                fallbackUsed: true
            });
            // Track fallback usage
            metrics_1.metrics.trackFallbackUsage(options.operation, true);
            return result;
        }
        catch (fallbackError) {
            logger_1.logger.error(`Fallback failed for ${options.operation}`, fallbackError, {
                operation: options.operation,
                originalError: originalError.message,
                userId: options.userId
            });
            // Track fallback failure
            metrics_1.metrics.trackFallbackUsage(options.operation, false);
            // Throw the original error if fallback fails
            throw originalError;
        }
    }
    /**
     * Create user-friendly error messages with recovery suggestions
     */
    static createUserFriendlyError(error, context) {
        // Handle specific error types
        if (error instanceof errors_1.AppError) {
            return error;
        }
        // AWS SDK errors
        if (error.name === 'ValidationException') {
            return new errors_1.ValidationError('The request contains invalid data. Please check your input and try again.', { originalError: error.message });
        }
        if (error.name === 'ResourceNotFoundException') {
            return new errors_1.NotFoundError('The requested resource was not found');
        }
        if (error.name === 'ConditionalCheckFailedException') {
            return new errors_1.BadRequestError('The operation could not be completed due to a conflict. The resource may have been modified.', { originalError: error.message });
        }
        if (error.name === 'ThrottlingException' || error.name === 'ProvisionedThroughputExceededException') {
            return new errors_1.RateLimitError(60); // Suggest 60 second retry
        }
        if (error.name === 'UnauthorizedOperation' || error.message.includes('unauthorized')) {
            return new errors_1.UnauthorizedError('You are not authorized to perform this action');
        }
        // Timeout errors
        if (error.name === 'TimeoutError' || error.message.includes('timeout')) {
            return new errors_1.TimeoutError(context || 'Operation');
        }
        // AI service specific errors
        if (error.message.toLowerCase().includes('bedrock') || error.message.toLowerCase().includes('ai')) {
            return new errors_1.AIServiceError('The AI service is temporarily unavailable. We\'ll show you recipes from our database instead.', { originalError: error.message }, true);
        }
        // Database errors
        if (error.message.includes('DynamoDB') || error.message.includes('database')) {
            return new errors_1.DatabaseError('We\'re experiencing database issues. Please try again in a moment.', { originalError: error.message });
        }
        // Network errors
        if (error.message.includes('network') || error.message.includes('connection')) {
            return new errors_1.ServiceUnavailableError('Network', 30);
        }
        // Default to internal error
        return new errors_1.AppError({
            code: errors_1.ErrorCode.INTERNAL_ERROR,
            message: 'An unexpected error occurred. Our team has been notified.',
            statusCode: 500,
            details: { originalError: error.message },
            recoverable: true,
            recoverySuggestion: 'Please try again in a few moments. If the problem persists, contact support.'
        });
    }
    /**
     * Validate request and throw appropriate errors
     */
    static validateRequest(body, requiredFields = []) {
        if (!body) {
            throw new errors_1.BadRequestError('Request body is required');
        }
        let parsedBody;
        try {
            parsedBody = JSON.parse(body);
        }
        catch (error) {
            throw new errors_1.BadRequestError('Invalid JSON in request body');
        }
        // Check required fields
        for (const field of requiredFields) {
            if (parsedBody[field] === undefined || parsedBody[field] === null) {
                throw new errors_1.ValidationError(`Missing required field: ${field}`, {
                    missingFields: [field]
                });
            }
        }
        return parsedBody;
    }
    /**
     * Extract user ID from event with proper error handling
     */
    static extractUserId(event) {
        const userId = event.requestContext?.authorizer?.claims?.sub;
        if (!userId) {
            throw new errors_1.UnauthorizedError('Authentication required. Please log in and try again.');
        }
        return userId;
    }
    /**
     * Handle AI service failures with graceful degradation
     */
    static async handleAIServiceFailure(aiOperation, fallbackOperation, context) {
        try {
            return await aiOperation();
        }
        catch (error) {
            logger_1.logger.warn(`AI service failed for ${context}, using fallback`, {
                error: error instanceof Error ? error.message : 'Unknown error',
                context
            });
            try {
                const result = await fallbackOperation();
                // Add warning to result if it's an object
                if (typeof result === 'object' && result !== null) {
                    result.warnings = [
                        ...(result.warnings || []),
                        {
                            message: 'AI service temporarily unavailable. Showing database recipes only.',
                            type: 'ai_fallback'
                        }
                    ];
                }
                return result;
            }
            catch (fallbackError) {
                logger_1.logger.error(`Both AI service and fallback failed for ${context}`, fallbackError);
                throw new errors_1.ServiceUnavailableError('Recipe suggestion service');
            }
        }
    }
    /**
     * Handle database operation failures with retry
     */
    static async handleDatabaseOperation(operation, operationName, retryCount = 3) {
        return await (0, utils_1.retryWithExponentialBackoff)(operation, {
            maxRetries: retryCount,
            baseDelay: 1000,
            shouldRetry: (error) => {
                // Retry on transient database errors
                return (0, errors_1.isTransientError)(error) ||
                    error.name === 'ProvisionedThroughputExceededException' ||
                    error.name === 'ThrottlingException' ||
                    error.message.includes('timeout');
            },
            onRetry: (error, attempt) => {
                logger_1.logger.warn(`Database operation retry for ${operationName}`, {
                    attempt,
                    error: error.message,
                    operationName
                });
            }
        });
    }
    /**
     * Create timeout wrapper for operations
     */
    static async withTimeout(operation, timeoutMs, operationName) {
        return Promise.race([
            operation(),
            new Promise((_, reject) => {
                setTimeout(() => {
                    reject(new errors_1.TimeoutError(operationName));
                }, timeoutMs);
            })
        ]);
    }
    /**
     * Handle batch operations with partial success
     */
    static async handleBatchOperation(items, operation, operationName) {
        const results = await Promise.allSettled(items.map(item => operation(item)));
        const successful = [];
        const failed = [];
        results.forEach((result, index) => {
            if (result.status === 'fulfilled') {
                successful.push(result.value);
            }
            else {
                failed.push({
                    item: items[index],
                    error: result.reason instanceof Error ? result.reason : new Error(String(result.reason))
                });
            }
        });
        const partialSuccess = successful.length > 0 && failed.length > 0;
        logger_1.logger.info(`Batch operation ${operationName} completed`, {
            total: items.length,
            successful: successful.length,
            failed: failed.length,
            partialSuccess,
            operationName
        });
        // Log failed items for debugging
        if (failed.length > 0) {
            logger_1.logger.warn(`Some items failed in batch operation ${operationName}`, {
                failedCount: failed.length,
                errors: failed.map(f => f.error.message)
            });
        }
        return { successful, failed, partialSuccess };
    }
}
exports.ErrorHandler = ErrorHandler;
/**
 * Decorator for Lambda handlers to add comprehensive error handling
 */
function withErrorHandling(options = {}) {
    return function (target, propertyName, descriptor) {
        const method = descriptor.value;
        descriptor.value = async function (...args) {
            const startTime = Date.now();
            const operation = options.operation || propertyName;
            try {
                const result = await method.apply(this, args);
                // Track success metrics
                const duration = Date.now() - startTime;
                metrics_1.metrics.trackApiRequest(200, duration, operation);
                return result;
            }
            catch (error) {
                const duration = Date.now() - startTime;
                // Handle error with comprehensive error handling
                const errorResponse = ErrorHandler.handleError(error, {
                    operation,
                    userId: options.userId,
                    requestId: options.requestId,
                    ...options
                });
                // Track error metrics
                metrics_1.metrics.trackApiRequest(errorResponse.statusCode, duration, operation);
                return errorResponse;
            }
        };
        return descriptor;
    };
}
/**
 * Circuit breaker implementation for external services
 */
class CircuitBreaker {
    constructor(serviceName, failureThreshold = 5, recoveryTimeoutMs = 60000) {
        this.serviceName = serviceName;
        this.failureThreshold = failureThreshold;
        this.recoveryTimeoutMs = recoveryTimeoutMs;
        this.failureCount = 0;
        this.lastFailureTime = null;
        this.state = 'CLOSED';
    }
    async execute(operation) {
        if (this.state === 'OPEN') {
            if (this.shouldAttemptReset()) {
                this.state = 'HALF_OPEN';
            }
            else {
                throw new errors_1.ServiceUnavailableError(this.serviceName, Math.ceil(this.recoveryTimeoutMs / 1000));
            }
        }
        try {
            const result = await operation();
            this.onSuccess();
            return result;
        }
        catch (error) {
            this.onFailure();
            throw error;
        }
    }
    shouldAttemptReset() {
        return this.lastFailureTime !== null &&
            Date.now() - this.lastFailureTime >= this.recoveryTimeoutMs;
    }
    onSuccess() {
        this.failureCount = 0;
        this.state = 'CLOSED';
        this.lastFailureTime = null;
    }
    onFailure() {
        this.failureCount++;
        this.lastFailureTime = Date.now();
        if (this.failureCount >= this.failureThreshold) {
            this.state = 'OPEN';
            logger_1.logger.warn(`Circuit breaker opened for ${this.serviceName}`, {
                failureCount: this.failureCount,
                serviceName: this.serviceName
            });
        }
    }
    getState() {
        return this.state;
    }
    getFailureCount() {
        return this.failureCount;
    }
}
exports.CircuitBreaker = CircuitBreaker;
