import { MasterIngredient } from './types';
export interface IngredientSearchResult {
    ingredient_id: string;
    name: string;
    normalized_name: string;
    category: string;
    aliases: string[];
    match_type: 'exact' | 'alias' | 'fuzzy';
    match_score: number;
}
export interface IngredientSearchOptions {
    limit?: number;
    category?: string;
    fuzzyThreshold?: number;
}
export declare class IngredientService {
    /**
     * Normalize Vietnamese text for search by removing diacritics
     */
    static normalizeVietnamese(text: string): string;
    /**
     * Calculate fuzzy match score using Levenshtein distance
     */
    static calculateFuzzyScore(search: string, target: string): number;
    /**
     * Calculate Levenshtein distance between two strings
     */
    private static levenshteinDistance;
    /**
     * Search ingredients by name with fuzzy matching
     */
    static searchIngredients(searchTerm: string, options?: IngredientSearchOptions): Promise<IngredientSearchResult[]>;
    /**
     * Get ingredient by ID
     */
    static getIngredientById(ingredientId: string): Promise<MasterIngredient | null>;
    /**
     * Get ingredients by category
     */
    static getIngredientsByCategory(category: string, limit?: number): Promise<MasterIngredient[]>;
    /**
     * Get all available categories
     */
    static getCategories(): Promise<string[]>;
    /**
     * Validate and normalize ingredient names
     */
    static validateIngredients(ingredientNames: string[]): Promise<{
        valid: Array<{
            original: string;
            matched: IngredientSearchResult;
        }>;
        invalid: Array<{
            original: string;
            suggestions: IngredientSearchResult[];
        }>;
    }>;
}
