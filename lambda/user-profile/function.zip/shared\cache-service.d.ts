/**
 * DynamoDB-based caching service for Smart Cooking MVP
 * Provides Redis-like caching functionality using DynamoDB TTL
 */
export declare class CacheService {
    private client;
    private tableName;
    constructor();
    /**
     * Get cached data by key
     */
    get(key: string): Promise<any>;
    /**
     * Set cached data with TTL
     */
    set(key: string, data: any, ttlSeconds?: number): Promise<void>;
    /**
     * Generate cache key from prefix and parameters
     */
    generateKey(prefix: string, params: Record<string, any>): string;
    /**
     * Delete cached item
     */
    delete(key: string): Promise<void>;
    /**
     * Get cache statistics
     */
    getStats(): Promise<{
        totalEntries: number;
        totalSize: number;
        hitRate: number;
    }>;
}
export declare function getCache(): CacheService;
export declare const CACHE_TTL: {
    readonly INGREDIENT_VALIDATION: number;
    readonly AI_SUGGESTIONS: number;
    readonly RECIPE_SEARCH: number;
    readonly USER_PROFILE: number;
    readonly MASTER_INGREDIENTS: number;
};
