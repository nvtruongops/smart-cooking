"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MAX_COOKING_SIZE = exports.MAX_POST_SIZE = exports.MAX_AVATAR_SIZE = void 0;
exports.generateAvatarPresignedUrl = generateAvatarPresignedUrl;
exports.generatePostPhotosPresignedUrls = generatePostPhotosPresignedUrls;
exports.generateCookingPhotoPresignedUrl = generateCookingPhotoPresignedUrl;
exports.getCloudFrontUrl = getCloudFrontUrl;
const client_s3_1 = require("@aws-sdk/client-s3");
const s3_request_presigner_1 = require("@aws-sdk/s3-request-presigner");
const logger_1 = require("./logger");
const s3Client = new client_s3_1.S3Client({ region: process.env.AWS_REGION || 'ap-southeast-1' });
const BUCKET_NAME = process.env.S3_BUCKET_NAME || process.env.USER_CONTENT_BUCKET || 'smart-cooking-images';
const CLOUDFRONT_DOMAIN = process.env.CLOUDFRONT_DOMAIN || 'd6grpgvslabt3.cloudfront.net';
// File type validation
const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
// Size limits (bytes)
exports.MAX_AVATAR_SIZE = 5 * 1024 * 1024; // 5MB
exports.MAX_POST_SIZE = 10 * 1024 * 1024; // 10MB
exports.MAX_COOKING_SIZE = 5 * 1024 * 1024; // 5MB
/**
 * Validate image file
 */
function validateImage(fileType, fileSize, maxSize) {
    if (!ALLOWED_IMAGE_TYPES.includes(fileType)) {
        throw new Error(`Invalid file type. Allowed: ${ALLOWED_IMAGE_TYPES.join(', ')}`);
    }
    if (fileSize > maxSize) {
        const maxMB = maxSize / (1024 * 1024);
        throw new Error(`File too large. Maximum ${maxMB}MB allowed`);
    }
    if (fileSize <= 0) {
        throw new Error('Invalid file size');
    }
}
/**
 * Generate presigned URL for avatar upload
 */
async function generateAvatarPresignedUrl(userId, request) {
    const { file_type, file_size } = request;
    // Validate
    validateImage(file_type, file_size, exports.MAX_AVATAR_SIZE);
    // Generate S3 key
    const extension = file_type.split('/')[1] || 'jpg';
    const key = `avatars/${userId}/avatar.${extension}`;
    logger_1.logger.info('Generating avatar presigned URL', { userId, key, file_type, file_size });
    try {
        // Create PutObject command
        const command = new client_s3_1.PutObjectCommand({
            Bucket: BUCKET_NAME,
            Key: key,
            ContentType: file_type
            // Note: Removed Metadata to avoid signature mismatch issues
            // Client must send exact headers specified in presigned URL
        });
        // Generate presigned URL (valid for 5 minutes)
        const uploadUrl = await (0, s3_request_presigner_1.getSignedUrl)(s3Client, command, {
            expiresIn: 300
        });
        return {
            upload_url: uploadUrl,
            key,
            expires_in: 300
        };
    }
    catch (error) {
        logger_1.logger.error('Failed to generate presigned URL', error);
        throw new Error('Failed to generate upload URL');
    }
}
/**
 * Generate presigned URLs for post photos (up to 5 images)
 */
async function generatePostPhotosPresignedUrls(postId, images) {
    // Validate max 5 images
    if (images.length > 5) {
        throw new Error('Maximum 5 images per post');
    }
    if (images.length === 0) {
        throw new Error('At least 1 image required');
    }
    logger_1.logger.info('Generating post presigned URLs', { postId, imageCount: images.length });
    const urls = [];
    for (let i = 0; i < images.length; i++) {
        const { file_type, file_size } = images[i];
        // Validate each image
        validateImage(file_type, file_size, exports.MAX_POST_SIZE);
        // Generate S3 key
        const extension = file_type.split('/')[1] || 'jpg';
        const key = `posts/${postId}/image-${i + 1}.${extension}`;
        try {
            const command = new client_s3_1.PutObjectCommand({
                Bucket: BUCKET_NAME,
                Key: key,
                ContentType: file_type
                // Note: Removed Metadata to avoid signature mismatch issues
            });
            const uploadUrl = await (0, s3_request_presigner_1.getSignedUrl)(s3Client, command, {
                expiresIn: 300
            });
            urls.push({
                upload_url: uploadUrl,
                key,
                expires_in: 300
            });
        }
        catch (error) {
            logger_1.logger.error('Failed to generate presigned URL for image', { index: i, error });
            throw new Error(`Failed to generate upload URL for image ${i + 1}`);
        }
    }
    return urls;
}
/**
 * Generate presigned URL for cooking completion photo
 */
async function generateCookingPhotoPresignedUrl(sessionId, request) {
    const { file_type, file_size } = request;
    // Validate
    validateImage(file_type, file_size, exports.MAX_COOKING_SIZE);
    // Generate S3 key
    const extension = file_type.split('/')[1] || 'jpg';
    const key = `cooking-sessions/${sessionId}/completion.${extension}`;
    logger_1.logger.info('Generating cooking photo presigned URL', { sessionId, key });
    try {
        const command = new client_s3_1.PutObjectCommand({
            Bucket: BUCKET_NAME,
            Key: key,
            ContentType: file_type
            // Note: Removed Metadata to avoid signature mismatch issues
        });
        const uploadUrl = await (0, s3_request_presigner_1.getSignedUrl)(s3Client, command, {
            expiresIn: 300
        });
        return {
            upload_url: uploadUrl,
            key,
            expires_in: 300
        };
    }
    catch (error) {
        logger_1.logger.error('Failed to generate presigned URL', error);
        throw new Error('Failed to generate upload URL');
    }
}
/**
 * Get CloudFront URL from S3 key
 */
function getCloudFrontUrl(key) {
    return `https://${CLOUDFRONT_DOMAIN}/${key}`;
}
