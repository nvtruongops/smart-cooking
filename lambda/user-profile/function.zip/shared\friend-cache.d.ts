/**
 * Friend List Caching Service
 * Task 18.2: Optimize social queries and performance
 *
 * Implements caching for frequently accessed friend lists to reduce DynamoDB reads
 * Uses in-memory cache with TTL for Lambda execution context reuse
 */
interface FriendCacheConfig {
    ttl: number;
    maxSize: number;
}
export declare class FriendCache {
    private cache;
    private config;
    private accessCount;
    constructor(config?: Partial<FriendCacheConfig>);
    /**
     * Get friend list from cache
     */
    get(userId: string): string[] | null;
    /**
     * Set friend list in cache
     */
    set(userId: string, friends: string[]): void;
    /**
     * Invalidate cache for a specific user
     */
    invalidate(userId: string): void;
    /**
     * Invalidate cache for both users in a friendship
     */
    invalidateFriendship(userId1: string, userId2: string): void;
    /**
     * Clear all cached data
     */
    clear(): void;
    /**
     * Get cache statistics
     */
    getStats(): {
        size: number;
        maxSize: number;
        hitRate: number;
        entries: number;
    };
    /**
     * Evict least recently used entry
     */
    private evictLRU;
    /**
     * Calculate cache hit rate (simplified)
     */
    private calculateHitRate;
}
/**
 * Get or create global friend cache instance
 */
export declare function getFriendCache(): FriendCache;
/**
 * Reset global cache (for testing)
 */
export declare function resetFriendCache(): void;
export {};
