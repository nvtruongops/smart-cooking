"use strict";
/**
 * Error Recovery Service
 * Implements recovery strategies for different types of failures
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorRecoveryManager = exports.ErrorRecoveryManager = void 0;
exports.executeWithRecovery = executeWithRecovery;
exports.healthCheckWithRecovery = healthCheckWithRecovery;
const logger_1 = require("./logger");
const metrics_1 = require("./metrics");
const error_handler_1 = require("./error-handler");
const errors_1 = require("./errors");
const dynamodb_1 = require("./dynamodb");
/**
 * Error Recovery Manager
 * Coordinates different recovery strategies based on error type
 */
class ErrorRecoveryManager {
    constructor() {
        this.strategies = [];
        this.circuitBreakers = new Map();
        this.registerDefaultStrategies();
    }
    /**
     * Register a recovery strategy
     */
    registerStrategy(strategy) {
        this.strategies.push(strategy);
        this.strategies.sort((a, b) => a.priority - b.priority);
    }
    /**
     * Attempt to recover from an error
     */
    async recover(error, context) {
        logger_1.logger.info(`Attempting error recovery for ${context.operation}`, {
            errorType: error.constructor.name,
            operation: context.operation,
            userId: context.userId
        });
        // Find applicable recovery strategies
        const applicableStrategies = this.strategies.filter(strategy => strategy.canHandle(error));
        if (applicableStrategies.length === 0) {
            logger_1.logger.warn(`No recovery strategy found for error in ${context.operation}`, {
                errorType: error.constructor.name,
                operation: context.operation
            });
            throw error;
        }
        // Try each strategy in priority order
        for (const strategy of applicableStrategies) {
            try {
                logger_1.logger.info(`Trying recovery strategy: ${strategy.name}`, {
                    operation: context.operation,
                    strategy: strategy.name
                });
                const result = await strategy.recover(error, context);
                logger_1.logger.info(`Recovery successful with strategy: ${strategy.name}`, {
                    operation: context.operation,
                    strategy: strategy.name
                });
                // Track successful recovery
                metrics_1.metrics.trackFallbackUsage(context.operation, true);
                return result;
            }
            catch (recoveryError) {
                logger_1.logger.warn(`Recovery strategy ${strategy.name} failed`, {
                    operation: context.operation,
                    strategy: strategy.name,
                    recoveryError: recoveryError instanceof Error ? recoveryError.message : 'Unknown error'
                });
                // Continue to next strategy
                continue;
            }
        }
        // All recovery strategies failed
        logger_1.logger.error(`All recovery strategies failed for ${context.operation}`, {
            errorType: error.constructor.name,
            operation: context.operation,
            strategiesAttempted: applicableStrategies.map(s => s.name)
        });
        metrics_1.metrics.trackFallbackUsage(context.operation, false);
        throw error;
    }
    /**
     * Get or create circuit breaker for a service
     */
    getCircuitBreaker(serviceName) {
        if (!this.circuitBreakers.has(serviceName)) {
            this.circuitBreakers.set(serviceName, new error_handler_1.CircuitBreaker(serviceName));
        }
        return this.circuitBreakers.get(serviceName);
    }
    /**
     * Register default recovery strategies
     */
    registerDefaultStrategies() {
        // AI Service Recovery Strategy
        this.registerStrategy({
            name: 'AI_SERVICE_FALLBACK',
            priority: 1,
            canHandle: (error) => error instanceof errors_1.AIServiceError ||
                error.message.includes('bedrock') ||
                error.message.includes('AI'),
            recover: async (error, context) => {
                return await this.recoverFromAIFailure(error, context);
            }
        });
        // Database Recovery Strategy
        this.registerStrategy({
            name: 'DATABASE_RETRY',
            priority: 2,
            canHandle: (error) => error instanceof errors_1.DatabaseError ||
                error.name === 'ThrottlingException' ||
                error.name === 'ProvisionedThroughputExceededException',
            recover: async (error, context) => {
                return await this.recoverFromDatabaseFailure(error, context);
            }
        });
        // Timeout Recovery Strategy
        this.registerStrategy({
            name: 'TIMEOUT_RETRY',
            priority: 3,
            canHandle: (error) => error instanceof errors_1.TimeoutError ||
                error.message.includes('timeout'),
            recover: async (error, context) => {
                return await this.recoverFromTimeout(error, context);
            }
        });
        // Partial Success Strategy
        this.registerStrategy({
            name: 'PARTIAL_SUCCESS',
            priority: 4,
            canHandle: (error) => error.message.includes('partial'),
            recover: async (error, context) => {
                return await this.recoverWithPartialSuccess(error, context);
            }
        });
        // Cache Fallback Strategy
        this.registerStrategy({
            name: 'CACHE_FALLBACK',
            priority: 5,
            canHandle: (error) => error instanceof errors_1.ServiceUnavailableError,
            recover: async (error, context) => {
                return await this.recoverFromCache(error, context);
            }
        });
    }
    /**
     * Recover from AI service failures
     */
    async recoverFromAIFailure(error, context) {
        logger_1.logger.info('Attempting AI service recovery', {
            operation: context.operation,
            userId: context.userId
        });
        // For AI suggestion failures, fall back to database-only recipes
        if (context.operation === 'ai-suggestion' && context.originalRequest) {
            const { ingredients, recipe_count } = context.originalRequest;
            // Query database for recipes matching ingredients
            const dbRecipes = await this.getDatabaseRecipes(ingredients, recipe_count);
            return {
                suggestions: dbRecipes,
                stats: {
                    requested: recipe_count,
                    from_database: dbRecipes.length,
                    from_ai: 0
                },
                warnings: [{
                        message: 'AI service temporarily unavailable. Showing database recipes only.',
                        type: 'ai_fallback'
                    }]
            };
        }
        throw new Error('No AI fallback available for this operation');
    }
    /**
     * Recover from database failures with retry
     */
    async recoverFromDatabaseFailure(error, context) {
        logger_1.logger.info('Attempting database recovery', {
            operation: context.operation,
            userId: context.userId
        });
        // Implement exponential backoff retry
        return await error_handler_1.ErrorHandler.handleDatabaseOperation(async () => {
            // Re-execute the original database operation
            throw new Error('Database operation retry not implemented for this context');
        }, context.operation, 2 // Reduced retry count for recovery
        );
    }
    /**
     * Recover from timeout errors
     */
    async recoverFromTimeout(error, context) {
        logger_1.logger.info('Attempting timeout recovery', {
            operation: context.operation,
            userId: context.userId
        });
        // For AI operations, fall back to faster database queries
        if (context.operation === 'ai-suggestion') {
            return await this.recoverFromAIFailure(error, context);
        }
        // For other operations, try with reduced scope
        if (context.originalRequest) {
            const reducedRequest = this.reduceRequestScope(context.originalRequest);
            logger_1.logger.info('Retrying with reduced scope', {
                operation: context.operation,
                originalScope: JSON.stringify(context.originalRequest),
                reducedScope: JSON.stringify(reducedRequest)
            });
            // This would need to be implemented per operation type
            throw new Error('Reduced scope retry not implemented for this operation');
        }
        throw error;
    }
    /**
     * Recover with partial success
     */
    async recoverWithPartialSuccess(error, context) {
        logger_1.logger.info('Attempting partial success recovery', {
            operation: context.operation,
            userId: context.userId
        });
        // Return whatever partial results are available
        if (context.metadata?.partialResults) {
            return {
                ...context.metadata.partialResults,
                warnings: [{
                        message: 'Some operations failed. Showing partial results.',
                        type: 'partial_success'
                    }]
            };
        }
        throw error;
    }
    /**
     * Recover from cache
     */
    async recoverFromCache(error, context) {
        logger_1.logger.info('Attempting cache recovery', {
            operation: context.operation,
            userId: context.userId
        });
        // Try to get cached results (this would need cache implementation)
        const cacheKey = this.generateCacheKey(context);
        // For now, just log that cache recovery was attempted
        logger_1.logger.info('Cache recovery not implemented', {
            cacheKey,
            operation: context.operation
        });
        throw error;
    }
    /**
     * Get database recipes as fallback for AI failures
     */
    async getDatabaseRecipes(ingredients, count) {
        try {
            // Query approved recipes that match the ingredients
            const recipes = [];
            // Try different cooking methods to get variety
            const cookingMethods = ['stir-fry', 'soup', 'steam', 'grill'];
            for (const method of cookingMethods) {
                if (recipes.length >= count)
                    break;
                const methodRecipes = await dynamodb_1.DynamoDBHelper.searchRecipesByMethod(method, 2);
                recipes.push(...methodRecipes.Items.slice(0, count - recipes.length));
            }
            // If still not enough, get any approved recipes
            if (recipes.length < count) {
                const additionalRecipes = await dynamodb_1.DynamoDBHelper.query({
                    IndexName: 'GSI2',
                    KeyConditionExpression: 'GSI2PK = :pk',
                    FilterExpression: 'is_approved = :approved',
                    ExpressionAttributeValues: {
                        ':pk': 'RECIPE#APPROVED',
                        ':approved': true
                    },
                    Limit: count - recipes.length
                });
                recipes.push(...additionalRecipes.Items);
            }
            return recipes.slice(0, count);
        }
        catch (error) {
            logger_1.logger.error('Failed to get database recipes for fallback', error);
            return [];
        }
    }
    /**
     * Reduce request scope for timeout recovery
     */
    reduceRequestScope(originalRequest) {
        const reduced = { ...originalRequest };
        // Reduce recipe count
        if (reduced.recipe_count && reduced.recipe_count > 1) {
            reduced.recipe_count = Math.max(1, Math.floor(reduced.recipe_count / 2));
        }
        // Reduce ingredient count
        if (reduced.ingredients && reduced.ingredients.length > 3) {
            reduced.ingredients = reduced.ingredients.slice(0, 3);
        }
        return reduced;
    }
    /**
     * Generate cache key for recovery
     */
    generateCacheKey(context) {
        const keyParts = [
            context.operation,
            context.userId || 'anonymous',
            JSON.stringify(context.originalRequest || {})
        ];
        return keyParts.join(':');
    }
}
exports.ErrorRecoveryManager = ErrorRecoveryManager;
/**
 * Singleton instance
 */
exports.errorRecoveryManager = new ErrorRecoveryManager();
/**
 * Convenience function to execute operation with error recovery
 */
async function executeWithRecovery(operation, context) {
    try {
        return await operation();
    }
    catch (error) {
        logger_1.logger.info(`Operation ${context.operation} failed, attempting recovery`, {
            errorType: error instanceof Error ? error.constructor.name : 'Unknown',
            operation: context.operation
        });
        return await exports.errorRecoveryManager.recover(error, context);
    }
}
/**
 * Health check with recovery
 */
async function healthCheckWithRecovery(serviceName, healthCheck) {
    try {
        await healthCheck();
        metrics_1.metrics.trackServiceHealth(serviceName, true);
        return { healthy: true };
    }
    catch (error) {
        logger_1.logger.warn(`Health check failed for ${serviceName}`, {
            error: error instanceof Error ? error.message : 'Unknown error'
        });
        // Attempt recovery
        try {
            await exports.errorRecoveryManager.recover(error, {
                operation: `health-check-${serviceName}`,
                metadata: { serviceName }
            });
            metrics_1.metrics.trackServiceHealth(serviceName, true);
            return {
                healthy: true,
                message: 'Recovered from health check failure',
                recoveryAttempted: true
            };
        }
        catch (recoveryError) {
            metrics_1.metrics.trackServiceHealth(serviceName, false);
            return {
                healthy: false,
                message: error instanceof Error ? error.message : 'Health check failed',
                recoveryAttempted: true
            };
        }
    }
}
