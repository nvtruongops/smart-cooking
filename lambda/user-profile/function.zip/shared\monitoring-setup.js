"use strict";
/**
 * Monitoring Setup Utility
 * Ensures all Lambda functions have proper monitoring configuration
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.initializeMonitoring = initializeMonitoring;
exports.withMonitoring = withMonitoring;
exports.withDatabaseMonitoring = withDatabaseMonitoring;
exports.withApiCallMonitoring = withApiCallMonitoring;
exports.trackBusinessEvent = trackBusinessEvent;
exports.trackUserActivity = trackUserActivity;
exports.trackSecurityEvent = trackSecurityEvent;
exports.performanceMonitor = performanceMonitor;
exports.trackAICost = trackAICost;
exports.validateMonitoringConfig = validateMonitoringConfig;
const logger_1 = require("./logger");
const metrics_1 = require("./metrics");
const tracer_1 = require("./tracer");
/**
 * Initialize monitoring for a Lambda function
 */
function initializeMonitoring(config) {
    // Set log level from config or environment
    if (config.logLevel) {
        process.env.LOG_LEVEL = config.logLevel;
    }
    // Set function name for metrics
    if (config.customDimensions) {
        Object.entries(config.customDimensions).forEach(([key, value]) => {
            process.env[`METRIC_DIMENSION_${key.toUpperCase()}`] = value;
        });
    }
    logger_1.logger.info('Monitoring initialized', {
        functionName: config.functionName,
        logLevel: process.env.LOG_LEVEL || 'INFO',
        xrayEnabled: tracer_1.tracer.isTracingEnabled(),
        environment: process.env.ENVIRONMENT || 'dev'
    });
}
/**
 * Wrapper for Lambda handlers with automatic monitoring
 */
function withMonitoring(functionName, handler, config) {
    return async (...args) => {
        const startTime = Date.now();
        // Initialize monitoring
        initializeMonitoring({
            functionName,
            ...config
        });
        // Extract event if it's an API Gateway event
        const event = args[0];
        if (event && event.requestContext) {
            logger_1.logger.initFromEvent(event);
            logger_1.logger.logFunctionStart(functionName, event);
            const userId = event.requestContext.authorizer?.claims?.sub;
            if (userId) {
                tracer_1.tracer.setUser(userId);
            }
        }
        try {
            const result = await tracer_1.tracer.captureBusinessOperation(`${functionName}-handler`, () => handler(...args), { functionName });
            const duration = Date.now() - startTime;
            logger_1.logger.logFunctionEnd(functionName, 200, duration);
            // Track successful API request if it's an API Gateway event
            if (event && event.httpMethod) {
                metrics_1.metrics.trackApiRequest(200, duration, functionName);
            }
            return result;
        }
        catch (error) {
            const duration = Date.now() - startTime;
            logger_1.logger.error(`${functionName} handler error`, error, { duration });
            logger_1.logger.logFunctionEnd(functionName, 500, duration);
            // Track failed API request if it's an API Gateway event
            if (event && event.httpMethod) {
                metrics_1.metrics.trackApiRequest(500, duration, functionName);
            }
            throw error;
        }
        finally {
            // Flush metrics before function ends
            await metrics_1.metrics.flush();
        }
    };
}
/**
 * Middleware for database operations with monitoring
 */
async function withDatabaseMonitoring(operation, tableName, fn) {
    return tracer_1.tracer.captureDatabaseOperation(operation, tableName, async () => {
        const start = Date.now();
        try {
            const result = await fn();
            const duration = Date.now() - start;
            metrics_1.metrics.trackDatabaseOperation(operation, duration, true);
            logger_1.logger.logDatabaseOperation(operation, tableName, duration, { success: true });
            return result;
        }
        catch (error) {
            const duration = Date.now() - start;
            metrics_1.metrics.trackDatabaseOperation(operation, duration, false);
            logger_1.logger.logDatabaseOperation(operation, tableName, duration, { success: false });
            throw error;
        }
    });
}
/**
 * Middleware for external API calls with monitoring
 */
async function withApiCallMonitoring(service, operation, fn, url) {
    return tracer_1.tracer.captureApiCall(service, operation, async () => {
        const start = Date.now();
        try {
            const result = await fn();
            const duration = Date.now() - start;
            logger_1.logger.logApiCall(service, operation, duration, { success: true, url });
            return result;
        }
        catch (error) {
            const duration = Date.now() - start;
            logger_1.logger.logApiCall(service, operation, duration, { success: false, url });
            throw error;
        }
    }, url);
}
/**
 * Helper to create CloudWatch custom metrics for business events
 */
function trackBusinessEvent(eventName, value = 1, dimensions) {
    metrics_1.metrics.addMetric({
        metricName: eventName,
        value,
        dimensions: {
            Environment: process.env.ENVIRONMENT || 'dev',
            FunctionName: process.env.AWS_LAMBDA_FUNCTION_NAME || 'unknown',
            ...dimensions
        }
    });
    logger_1.logger.logBusinessMetric(eventName, value, 'count', dimensions);
}
/**
 * Helper to track user activity
 */
function trackUserActivity(activityType, userId, metadata) {
    metrics_1.metrics.trackUserActivity(activityType, userId);
    logger_1.logger.info(`User activity: ${activityType}`, {
        userId,
        activityType,
        ...metadata
    });
}
/**
 * Helper to track security events
 */
function trackSecurityEvent(event, severity, metadata) {
    logger_1.logger.logSecurityEvent(event, severity, metadata);
    // Track as metric for alerting
    metrics_1.metrics.addMetric({
        metricName: 'SecurityEvent',
        value: 1,
        dimensions: {
            EventType: event,
            Severity: severity,
            Environment: process.env.ENVIRONMENT || 'dev'
        }
    });
}
/**
 * Performance monitoring decorator
 */
function performanceMonitor(operationName) {
    return function (target, propertyKey, descriptor) {
        const originalMethod = descriptor.value;
        descriptor.value = async function (...args) {
            const start = Date.now();
            try {
                const result = await originalMethod.apply(this, args);
                const duration = Date.now() - start;
                logger_1.logger.logPerformance(operationName, duration, { success: true });
                return result;
            }
            catch (error) {
                const duration = Date.now() - start;
                logger_1.logger.logPerformance(operationName, duration, { success: false });
                throw error;
            }
        };
        return descriptor;
    };
}
/**
 * Cost tracking helper for AI operations
 */
function trackAICost(modelId, inputTokens, outputTokens, duration, estimatedCost) {
    metrics_1.metrics.trackAiUsage(modelId, inputTokens, outputTokens, duration, estimatedCost);
    logger_1.logger.info('AI operation completed', {
        modelId,
        inputTokens,
        outputTokens,
        duration,
        estimatedCost
    });
}
/**
 * Validate monitoring environment variables
 */
function validateMonitoringConfig() {
    const requiredVars = [
        'AWS_LAMBDA_FUNCTION_NAME',
        'AWS_REGION'
    ];
    const optionalVars = [
        'LOG_LEVEL',
        'ENVIRONMENT',
        '_X_AMZN_TRACE_ID'
    ];
    const missingVars = requiredVars.filter(varName => !process.env[varName]);
    const warnings = optionalVars
        .filter(varName => !process.env[varName])
        .map(varName => `Optional environment variable ${varName} not set`);
    return {
        isValid: missingVars.length === 0,
        missingVars,
        warnings
    };
}
