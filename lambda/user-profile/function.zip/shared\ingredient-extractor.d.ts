/**
 * Ingredient Extractor Service
 * Extracts ingredient names from recipe ingredients and saves to master DB
 */
export interface ExtractedIngredient {
    original: string;
    name: string;
    quantity?: string;
    unit?: string;
}
export interface IngredientExtractionResult {
    extracted: ExtractedIngredient[];
    savedToMaster: number;
    alreadyExists: number;
    failed: number;
}
export declare class IngredientExtractor {
    /**
     * Extract ingredient name from a recipe ingredient string
     * Examples:
     *   "300g thịt gà" → { name: "thịt gà", quantity: "300", unit: "g" }
     *   "2 củ cà rốt" → { name: "cà rốt", quantity: "2", unit: "củ" }
     *   "1 chút muối" → { name: "muối", quantity: "1", unit: "chút" }
     */
    static extractIngredientName(ingredientString: string): ExtractedIngredient;
    /**
     * Extract all ingredient names from a recipe's ingredient list
     */
    static extractIngredientsFromRecipe(ingredients: string[]): ExtractedIngredient[];
    /**
     * Save an ingredient to master database if it doesn't exist
     * Returns true if saved, false if already exists
     */
    static saveToMasterDB(ingredientName: string, sourceRecipeId?: string): Promise<boolean>;
    /**
     * Simple ingredient categorization based on keywords
     */
    private static categorizeIngredient;
    /**
     * Process all ingredients from a recipe and save to master DB
     */
    static processRecipeIngredients(recipeIngredients: string[], recipeId: string): Promise<IngredientExtractionResult>;
    /**
     * Batch process multiple recipes
     */
    static batchProcessRecipes(recipes: Array<{
        recipe_id: string;
        ingredients: string[];
    }>): Promise<{
        totalProcessed: number;
        totalExtracted: number;
        totalSavedToMaster: number;
        totalAlreadyExists: number;
        totalFailed: number;
    }>;
}
