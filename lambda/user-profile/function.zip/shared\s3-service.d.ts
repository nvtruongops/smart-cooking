export declare const MAX_AVATAR_SIZE: number;
export declare const MAX_POST_SIZE: number;
export declare const MAX_COOKING_SIZE: number;
export interface PresignedUrlRequest {
    file_type: string;
    file_size: number;
}
export interface PresignedUrlResponse {
    upload_url: string;
    key: string;
    expires_in: number;
}
/**
 * Generate presigned URL for avatar upload
 */
export declare function generateAvatarPresignedUrl(userId: string, request: PresignedUrlRequest): Promise<PresignedUrlResponse>;
/**
 * Generate presigned URLs for post photos (up to 5 images)
 */
export declare function generatePostPhotosPresignedUrls(postId: string, images: PresignedUrlRequest[]): Promise<PresignedUrlResponse[]>;
/**
 * Generate presigned URL for cooking completion photo
 */
export declare function generateCookingPhotoPresignedUrl(sessionId: string, request: PresignedUrlRequest): Promise<PresignedUrlResponse>;
/**
 * Get CloudFront URL from S3 key
 */
export declare function getCloudFrontUrl(key: string): string;
