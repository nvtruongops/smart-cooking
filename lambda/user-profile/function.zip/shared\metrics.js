"use strict";
/**
 * CloudWatch custom metrics utility for Lambda functions
 * Tracks business metrics, AI usage, costs, and performance
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.metrics = exports.MetricsPublisher = void 0;
exports.trackOperation = trackOperation;
const client_cloudwatch_1 = require("@aws-sdk/client-cloudwatch");
const logger_1 = require("./logger");
const cloudWatch = new client_cloudwatch_1.CloudWatchClient({});
class MetricsPublisher {
    constructor(namespace = 'SmartCooking', defaultDimensions = {}) {
        this.metricsBuffer = [];
        this.MAX_BUFFER_SIZE = 20; // CloudWatch max is 20 metrics per request
        this.namespace = namespace;
        this.defaultDimensions = {
            Environment: process.env.ENVIRONMENT || 'dev',
            FunctionName: process.env.AWS_LAMBDA_FUNCTION_NAME || 'unknown',
            ...defaultDimensions
        };
    }
    /**
     * Add a metric to the buffer
     */
    addMetric(data) {
        this.metricsBuffer.push({
            ...data,
            timestamp: data.timestamp || new Date()
        });
        // Auto-flush if buffer is full
        if (this.metricsBuffer.length >= this.MAX_BUFFER_SIZE) {
            this.flush().catch(error => {
                logger_1.logger.error('Failed to auto-flush metrics', error);
            });
        }
    }
    /**
     * Publish all buffered metrics to CloudWatch
     */
    async flush() {
        if (this.metricsBuffer.length === 0) {
            return;
        }
        const metrics = [...this.metricsBuffer];
        this.metricsBuffer = [];
        try {
            const metricData = metrics.map(metric => {
                const dimensions = {
                    ...this.defaultDimensions,
                    ...(metric.dimensions || {})
                };
                return {
                    MetricName: metric.metricName,
                    Value: metric.value,
                    Unit: metric.unit || client_cloudwatch_1.StandardUnit.None,
                    Timestamp: metric.timestamp,
                    Dimensions: Object.entries(dimensions).map(([name, value]) => ({
                        Name: name,
                        Value: value
                    }))
                };
            });
            await cloudWatch.send(new client_cloudwatch_1.PutMetricDataCommand({
                Namespace: this.namespace,
                MetricData: metricData
            }));
            logger_1.logger.debug('Published metrics to CloudWatch', {
                namespace: this.namespace,
                metricCount: metrics.length
            });
        }
        catch (error) {
            logger_1.logger.error('Failed to publish metrics to CloudWatch', error, {
                namespace: this.namespace,
                metricCount: metrics.length
            });
            // Re-add metrics to buffer for retry
            this.metricsBuffer.push(...metrics);
        }
    }
    /**
     * Publish a single metric immediately
     */
    async publishMetric(data) {
        this.addMetric(data);
        await this.flush();
    }
    /**
     * Track API request
     */
    trackApiRequest(statusCode, duration, endpoint) {
        this.addMetric({
            metricName: 'ApiRequest',
            value: 1,
            unit: client_cloudwatch_1.StandardUnit.Count,
            dimensions: {
                StatusCode: statusCode.toString(),
                ...(endpoint ? { Endpoint: endpoint } : {})
            }
        });
        this.addMetric({
            metricName: 'ApiLatency',
            value: duration,
            unit: client_cloudwatch_1.StandardUnit.Milliseconds,
            dimensions: endpoint ? { Endpoint: endpoint } : undefined
        });
        if (statusCode >= 400) {
            this.addMetric({
                metricName: 'ApiError',
                value: 1,
                unit: client_cloudwatch_1.StandardUnit.Count,
                dimensions: {
                    StatusCode: statusCode.toString(),
                    ...(endpoint ? { Endpoint: endpoint } : {})
                }
            });
        }
    }
    /**
     * Track AI model usage
     */
    trackAiUsage(modelId, inputTokens, outputTokens, duration, cost) {
        this.addMetric({
            metricName: 'AiInvocation',
            value: 1,
            unit: client_cloudwatch_1.StandardUnit.Count,
            dimensions: { ModelId: modelId }
        });
        this.addMetric({
            metricName: 'AiInputTokens',
            value: inputTokens,
            unit: client_cloudwatch_1.StandardUnit.Count,
            dimensions: { ModelId: modelId }
        });
        this.addMetric({
            metricName: 'AiOutputTokens',
            value: outputTokens,
            unit: client_cloudwatch_1.StandardUnit.Count,
            dimensions: { ModelId: modelId }
        });
        this.addMetric({
            metricName: 'AiLatency',
            value: duration,
            unit: client_cloudwatch_1.StandardUnit.Milliseconds,
            dimensions: { ModelId: modelId }
        });
        if (cost !== undefined) {
            this.addMetric({
                metricName: 'AiCost',
                value: cost,
                unit: client_cloudwatch_1.StandardUnit.None, // USD
                dimensions: { ModelId: modelId }
            });
        }
    }
    /**
     * Track database operation
     */
    trackDatabaseOperation(operation, duration, success, itemCount) {
        this.addMetric({
            metricName: 'DatabaseOperation',
            value: 1,
            unit: client_cloudwatch_1.StandardUnit.Count,
            dimensions: {
                Operation: operation,
                Success: success.toString()
            }
        });
        this.addMetric({
            metricName: 'DatabaseLatency',
            value: duration,
            unit: client_cloudwatch_1.StandardUnit.Milliseconds,
            dimensions: { Operation: operation }
        });
        if (itemCount !== undefined) {
            this.addMetric({
                metricName: 'DatabaseItemCount',
                value: itemCount,
                unit: client_cloudwatch_1.StandardUnit.Count,
                dimensions: { Operation: operation }
            });
        }
        if (!success) {
            this.addMetric({
                metricName: 'DatabaseError',
                value: 1,
                unit: client_cloudwatch_1.StandardUnit.Count,
                dimensions: { Operation: operation }
            });
        }
    }
    /**
     * Track cache hit/miss
     */
    trackCacheOperation(hit, cacheType = 'default') {
        this.addMetric({
            metricName: hit ? 'CacheHit' : 'CacheMiss',
            value: 1,
            unit: client_cloudwatch_1.StandardUnit.Count,
            dimensions: { CacheType: cacheType }
        });
    }
    /**
     * Track business metric: Recipe suggestion
     */
    trackRecipeSuggestion(fromDatabase, fromAi, ingredientCount) {
        this.addMetric({
            metricName: 'RecipeSuggestion',
            value: 1,
            unit: client_cloudwatch_1.StandardUnit.Count
        });
        this.addMetric({
            metricName: 'RecipesFromDatabase',
            value: fromDatabase,
            unit: client_cloudwatch_1.StandardUnit.Count
        });
        this.addMetric({
            metricName: 'RecipesFromAi',
            value: fromAi,
            unit: client_cloudwatch_1.StandardUnit.Count
        });
        this.addMetric({
            metricName: 'IngredientCount',
            value: ingredientCount,
            unit: client_cloudwatch_1.StandardUnit.Count
        });
        // Track database coverage percentage
        const total = fromDatabase + fromAi;
        if (total > 0) {
            const coveragePercent = (fromDatabase / total) * 100;
            this.addMetric({
                metricName: 'DatabaseCoveragePercent',
                value: coveragePercent,
                unit: client_cloudwatch_1.StandardUnit.Percent
            });
        }
    }
    /**
     * Track cooking session
     */
    trackCookingSession(status, recipeSource) {
        this.addMetric({
            metricName: 'CookingSession',
            value: 1,
            unit: client_cloudwatch_1.StandardUnit.Count,
            dimensions: {
                Status: status,
                RecipeSource: recipeSource
            }
        });
    }
    /**
     * Track recipe rating
     */
    trackRecipeRating(rating, recipeSource, isVerifiedCook) {
        this.addMetric({
            metricName: 'RecipeRating',
            value: rating,
            unit: client_cloudwatch_1.StandardUnit.None,
            dimensions: {
                RecipeSource: recipeSource,
                VerifiedCook: isVerifiedCook.toString()
            }
        });
        this.addMetric({
            metricName: 'RatingSubmission',
            value: 1,
            unit: client_cloudwatch_1.StandardUnit.Count,
            dimensions: {
                RecipeSource: recipeSource,
                RatingValue: rating.toString()
            }
        });
    }
    /**
     * Track recipe auto-approval
     */
    trackRecipeAutoApproval(approved, averageRating, ratingCount) {
        this.addMetric({
            metricName: 'RecipeAutoApproval',
            value: 1,
            unit: client_cloudwatch_1.StandardUnit.Count,
            dimensions: {
                Approved: approved.toString()
            }
        });
        if (approved) {
            this.addMetric({
                metricName: 'ApprovedRecipeRating',
                value: averageRating,
                unit: client_cloudwatch_1.StandardUnit.None
            });
            this.addMetric({
                metricName: 'ApprovedRecipeRatingCount',
                value: ratingCount,
                unit: client_cloudwatch_1.StandardUnit.Count
            });
        }
    }
    /**
     * Track ingredient validation
     */
    trackIngredientValidation(totalIngredients, validIngredients, invalidIngredients) {
        this.addMetric({
            metricName: 'IngredientValidation',
            value: 1,
            unit: client_cloudwatch_1.StandardUnit.Count
        });
        this.addMetric({
            metricName: 'ValidIngredients',
            value: validIngredients,
            unit: client_cloudwatch_1.StandardUnit.Count
        });
        this.addMetric({
            metricName: 'InvalidIngredients',
            value: invalidIngredients,
            unit: client_cloudwatch_1.StandardUnit.Count
        });
        const validationRate = totalIngredients > 0 ? (validIngredients / totalIngredients) * 100 : 100;
        this.addMetric({
            metricName: 'IngredientValidationRate',
            value: validationRate,
            unit: client_cloudwatch_1.StandardUnit.Percent
        });
    }
    /**
     * Track user activity
     */
    trackUserActivity(activityType, userId) {
        this.addMetric({
            metricName: 'UserActivity',
            value: 1,
            unit: client_cloudwatch_1.StandardUnit.Count,
            dimensions: {
                ActivityType: activityType,
                ...(userId ? { UserId: userId } : {})
            }
        });
    }
    /**
     * Track error occurrence
     */
    trackError(operation, errorType, statusCode) {
        this.addMetric({
            metricName: 'Error',
            value: 1,
            unit: client_cloudwatch_1.StandardUnit.Count,
            dimensions: {
                Operation: operation,
                ErrorType: errorType,
                StatusCode: statusCode.toString()
            }
        });
        // Track error severity
        const severity = statusCode >= 500 ? 'Critical' : statusCode >= 400 ? 'Warning' : 'Info';
        this.addMetric({
            metricName: 'ErrorSeverity',
            value: 1,
            unit: client_cloudwatch_1.StandardUnit.Count,
            dimensions: {
                Severity: severity,
                Operation: operation
            }
        });
    }
    /**
     * Track fallback usage
     */
    trackFallbackUsage(operation, successful) {
        this.addMetric({
            metricName: 'FallbackUsage',
            value: 1,
            unit: client_cloudwatch_1.StandardUnit.Count,
            dimensions: {
                Operation: operation,
                Successful: successful.toString()
            }
        });
        if (successful) {
            this.addMetric({
                metricName: 'FallbackSuccess',
                value: 1,
                unit: client_cloudwatch_1.StandardUnit.Count,
                dimensions: { Operation: operation }
            });
        }
        else {
            this.addMetric({
                metricName: 'FallbackFailure',
                value: 1,
                unit: client_cloudwatch_1.StandardUnit.Count,
                dimensions: { Operation: operation }
            });
        }
    }
    /**
     * Track retry attempts
     */
    trackRetryAttempt(operation, attempt, successful) {
        this.addMetric({
            metricName: 'RetryAttempt',
            value: 1,
            unit: client_cloudwatch_1.StandardUnit.Count,
            dimensions: {
                Operation: operation,
                Attempt: attempt.toString(),
                Successful: successful.toString()
            }
        });
        if (successful) {
            this.addMetric({
                metricName: 'RetrySuccess',
                value: attempt,
                unit: client_cloudwatch_1.StandardUnit.Count,
                dimensions: { Operation: operation }
            });
        }
    }
    /**
     * Track circuit breaker state changes
     */
    trackCircuitBreakerState(serviceName, state, failureCount) {
        this.addMetric({
            metricName: 'CircuitBreakerState',
            value: 1,
            unit: client_cloudwatch_1.StandardUnit.Count,
            dimensions: {
                ServiceName: serviceName,
                State: state
            }
        });
        this.addMetric({
            metricName: 'CircuitBreakerFailureCount',
            value: failureCount,
            unit: client_cloudwatch_1.StandardUnit.Count,
            dimensions: { ServiceName: serviceName }
        });
    }
    /**
     * Track timeout occurrences
     */
    trackTimeout(operation, timeoutMs, actualDuration) {
        this.addMetric({
            metricName: 'Timeout',
            value: 1,
            unit: client_cloudwatch_1.StandardUnit.Count,
            dimensions: { Operation: operation }
        });
        this.addMetric({
            metricName: 'TimeoutDuration',
            value: timeoutMs,
            unit: client_cloudwatch_1.StandardUnit.Milliseconds,
            dimensions: { Operation: operation }
        });
        this.addMetric({
            metricName: 'ActualDurationBeforeTimeout',
            value: actualDuration,
            unit: client_cloudwatch_1.StandardUnit.Milliseconds,
            dimensions: { Operation: operation }
        });
    }
    /**
     * Track service health
     */
    trackServiceHealth(serviceName, healthy, responseTime) {
        this.addMetric({
            metricName: 'ServiceHealth',
            value: healthy ? 1 : 0,
            unit: client_cloudwatch_1.StandardUnit.None,
            dimensions: { ServiceName: serviceName }
        });
        if (responseTime !== undefined) {
            this.addMetric({
                metricName: 'ServiceHealthCheckLatency',
                value: responseTime,
                unit: client_cloudwatch_1.StandardUnit.Milliseconds,
                dimensions: { ServiceName: serviceName }
            });
        }
    }
}
exports.MetricsPublisher = MetricsPublisher;
// Export singleton instance
exports.metrics = new MetricsPublisher();
/**
 * Helper to track operation with automatic metrics
 */
async function trackOperation(operationName, operation, operationType = 'api') {
    const start = Date.now();
    try {
        const result = await operation();
        const duration = Date.now() - start;
        if (operationType === 'database') {
            exports.metrics.trackDatabaseOperation(operationName, duration, true);
        }
        else if (operationType === 'api') {
            exports.metrics.trackApiRequest(200, duration, operationName);
        }
        return result;
    }
    catch (error) {
        const duration = Date.now() - start;
        if (operationType === 'database') {
            exports.metrics.trackDatabaseOperation(operationName, duration, false);
        }
        else if (operationType === 'api') {
            exports.metrics.trackApiRequest(500, duration, operationName);
        }
        throw error;
    }
}
