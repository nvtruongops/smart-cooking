/**
 * Error Recovery Service
 * Implements recovery strategies for different types of failures
 */
import { CircuitBreaker } from './error-handler';
export interface RecoveryStrategy {
    name: string;
    canHandle: (error: Error) => boolean;
    recover: (error: Error, context: any) => Promise<any>;
    priority: number;
}
export interface RecoveryContext {
    operation: string;
    userId?: string;
    requestId?: string;
    originalRequest?: any;
    metadata?: any;
}
/**
 * Error Recovery Manager
 * Coordinates different recovery strategies based on error type
 */
export declare class ErrorRecoveryManager {
    private strategies;
    private circuitBreakers;
    constructor();
    /**
     * Register a recovery strategy
     */
    registerStrategy(strategy: RecoveryStrategy): void;
    /**
     * Attempt to recover from an error
     */
    recover(error: Error, context: RecoveryContext): Promise<any>;
    /**
     * Get or create circuit breaker for a service
     */
    getCircuitBreaker(serviceName: string): CircuitBreaker;
    /**
     * Register default recovery strategies
     */
    private registerDefaultStrategies;
    /**
     * Recover from AI service failures
     */
    private recoverFromAIFailure;
    /**
     * Recover from database failures with retry
     */
    private recoverFromDatabaseFailure;
    /**
     * Recover from timeout errors
     */
    private recoverFromTimeout;
    /**
     * Recover with partial success
     */
    private recoverWithPartialSuccess;
    /**
     * Recover from cache
     */
    private recoverFromCache;
    /**
     * Get database recipes as fallback for AI failures
     */
    private getDatabaseRecipes;
    /**
     * Reduce request scope for timeout recovery
     */
    private reduceRequestScope;
    /**
     * Generate cache key for recovery
     */
    private generateCacheKey;
}
/**
 * Singleton instance
 */
export declare const errorRecoveryManager: ErrorRecoveryManager;
/**
 * Convenience function to execute operation with error recovery
 */
export declare function executeWithRecovery<T>(operation: () => Promise<T>, context: RecoveryContext): Promise<T>;
/**
 * Health check with recovery
 */
export declare function healthCheckWithRecovery(serviceName: string, healthCheck: () => Promise<void>): Promise<{
    healthy: boolean;
    message?: string;
    recoveryAttempted?: boolean;
}>;
