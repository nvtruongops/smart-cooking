"use strict";
// Shared TypeScript types for Smart Cooking MVP
Object.defineProperty(exports, "__esModule", { value: true });
