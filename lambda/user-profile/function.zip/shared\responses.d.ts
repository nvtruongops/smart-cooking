import { APIResponse } from './types';
export declare function successResponse(data: any, statusCode?: number): APIResponse;
export declare function errorResponse(statusCode: number, error: string, message: string, details?: any): APIResponse;
export declare class AppError extends Error {
    statusCode: number;
    errorCode: string;
    details: any;
    constructor(statusCode: number, errorCode: string, message: string, details?: any);
}
export declare function handleError(error: any): APIResponse;
