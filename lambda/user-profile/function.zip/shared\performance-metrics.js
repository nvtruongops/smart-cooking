"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PerformanceTimer = exports.PerformanceMetrics = void 0;
exports.getPerformanceMetrics = getPerformanceMetrics;
const client_cloudwatch_1 = require("@aws-sdk/client-cloudwatch");
const logger_1 = require("./logger");
/**
 * Performance metrics collection and reporting service
 * Tracks optimization metrics for Smart Cooking MVP
 */
class PerformanceMetrics {
    constructor() {
        this.cloudwatch = new client_cloudwatch_1.CloudWatchClient({ region: process.env.AWS_REGION });
        this.environment = process.env.ENVIRONMENT || 'dev';
    }
    /**
     * Record cache performance metrics
     */
    async recordCacheMetrics(metrics) {
        try {
            const metricData = [
                {
                    MetricName: 'CacheHitRate',
                    Value: metrics.hitRate,
                    Unit: client_cloudwatch_1.StandardUnit.Percent,
                    Dimensions: [
                        { Name: 'Environment', Value: this.environment },
                        { Name: 'Operation', Value: metrics.operation }
                    ]
                },
                {
                    MetricName: 'CacheResponseTime',
                    Value: metrics.responseTime,
                    Unit: client_cloudwatch_1.StandardUnit.Milliseconds,
                    Dimensions: [
                        { Name: 'Environment', Value: this.environment },
                        { Name: 'Operation', Value: metrics.operation }
                    ]
                }
            ];
            if (metrics.cacheSize !== undefined) {
                metricData.push({
                    MetricName: 'CacheSize',
                    Value: metrics.cacheSize,
                    Unit: client_cloudwatch_1.StandardUnit.Bytes,
                    Dimensions: [
                        { Name: 'Environment', Value: this.environment },
                        { Name: 'Operation', Value: metrics.operation }
                    ]
                });
            }
            await this.publishMetrics('SmartCooking/Performance/Cache', metricData);
        }
        catch (error) {
            logger_1.logger.error('Failed to record cache metrics', {
                metrics,
                error: error instanceof Error ? error.message : 'Unknown error'
            });
        }
    }
    /**
     * Record database query performance metrics
     */
    async recordDatabaseMetrics(metrics) {
        try {
            const metricData = [
                {
                    MetricName: 'DatabaseQueryTime',
                    Value: metrics.queryTime,
                    Unit: client_cloudwatch_1.StandardUnit.Milliseconds,
                    Dimensions: [
                        { Name: 'Environment', Value: this.environment },
                        { Name: 'Operation', Value: metrics.operation },
                        { Name: 'IndexUsed', Value: metrics.indexUsed || 'primary' }
                    ]
                },
                {
                    MetricName: 'DatabaseItemCount',
                    Value: metrics.itemCount,
                    Unit: client_cloudwatch_1.StandardUnit.Count,
                    Dimensions: [
                        { Name: 'Environment', Value: this.environment },
                        { Name: 'Operation', Value: metrics.operation }
                    ]
                }
            ];
            if (metrics.filterApplied !== undefined) {
                metricData.push({
                    MetricName: 'DatabaseFilterEfficiency',
                    Value: metrics.filterApplied ? 1 : 0,
                    Unit: client_cloudwatch_1.StandardUnit.Count,
                    Dimensions: [
                        { Name: 'Environment', Value: this.environment },
                        { Name: 'Operation', Value: metrics.operation }
                    ]
                });
            }
            await this.publishMetrics('SmartCooking/Performance/Database', metricData);
        }
        catch (error) {
            logger_1.logger.error('Failed to record database metrics', {
                metrics,
                error: error instanceof Error ? error.message : 'Unknown error'
            });
        }
    }
    /**
     * Record Lambda function performance metrics
     */
    async recordLambdaMetrics(metrics) {
        try {
            const memoryUtilization = (metrics.memoryUsed / metrics.memoryAllocated) * 100;
            const metricData = [
                {
                    MetricName: 'LambdaDuration',
                    Value: metrics.duration,
                    Unit: client_cloudwatch_1.StandardUnit.Milliseconds,
                    Dimensions: [
                        { Name: 'Environment', Value: this.environment },
                        { Name: 'FunctionName', Value: metrics.functionName }
                    ]
                },
                {
                    MetricName: 'LambdaMemoryUtilization',
                    Value: memoryUtilization,
                    Unit: client_cloudwatch_1.StandardUnit.Percent,
                    Dimensions: [
                        { Name: 'Environment', Value: this.environment },
                        { Name: 'FunctionName', Value: metrics.functionName }
                    ]
                },
                {
                    MetricName: 'LambdaMemoryUsed',
                    Value: metrics.memoryUsed,
                    Unit: client_cloudwatch_1.StandardUnit.Megabytes,
                    Dimensions: [
                        { Name: 'Environment', Value: this.environment },
                        { Name: 'FunctionName', Value: metrics.functionName }
                    ]
                }
            ];
            if (metrics.coldStart !== undefined) {
                metricData.push({
                    MetricName: 'LambdaColdStart',
                    Value: metrics.coldStart ? 1 : 0,
                    Unit: client_cloudwatch_1.StandardUnit.Count,
                    Dimensions: [
                        { Name: 'Environment', Value: this.environment },
                        { Name: 'FunctionName', Value: metrics.functionName }
                    ]
                });
            }
            if (metrics.errorCount !== undefined) {
                metricData.push({
                    MetricName: 'LambdaErrors',
                    Value: metrics.errorCount,
                    Unit: client_cloudwatch_1.StandardUnit.Count,
                    Dimensions: [
                        { Name: 'Environment', Value: this.environment },
                        { Name: 'FunctionName', Value: metrics.functionName }
                    ]
                });
            }
            await this.publishMetrics('SmartCooking/Performance/Lambda', metricData);
        }
        catch (error) {
            logger_1.logger.error('Failed to record Lambda metrics', {
                metrics,
                error: error instanceof Error ? error.message : 'Unknown error'
            });
        }
    }
    /**
     * Record cost optimization metrics
     */
    async recordCostOptimizationMetrics(metrics) {
        try {
            const metricData = [
                {
                    MetricName: 'CostSavings',
                    Value: metrics.costSavings,
                    Unit: client_cloudwatch_1.StandardUnit.None,
                    Dimensions: [
                        { Name: 'Environment', Value: this.environment },
                        { Name: 'Operation', Value: metrics.operation },
                        { Name: 'Currency', Value: 'USD' }
                    ]
                },
                {
                    MetricName: 'DatabaseUsageRatio',
                    Value: metrics.dbUsageRatio,
                    Unit: client_cloudwatch_1.StandardUnit.Percent,
                    Dimensions: [
                        { Name: 'Environment', Value: this.environment },
                        { Name: 'Operation', Value: metrics.operation }
                    ]
                },
                {
                    MetricName: 'AIUsageRatio',
                    Value: metrics.aiUsageRatio,
                    Unit: client_cloudwatch_1.StandardUnit.Percent,
                    Dimensions: [
                        { Name: 'Environment', Value: this.environment },
                        { Name: 'Operation', Value: metrics.operation }
                    ]
                },
                {
                    MetricName: 'OptimizationEffectiveness',
                    Value: metrics.dbUsageRatio, // Higher DB usage = better optimization
                    Unit: client_cloudwatch_1.StandardUnit.Percent,
                    Dimensions: [
                        { Name: 'Environment', Value: this.environment },
                        { Name: 'Strategy', Value: metrics.optimizationStrategy }
                    ]
                }
            ];
            await this.publishMetrics('SmartCooking/Performance/CostOptimization', metricData);
        }
        catch (error) {
            logger_1.logger.error('Failed to record cost optimization metrics', {
                metrics,
                error: error instanceof Error ? error.message : 'Unknown error'
            });
        }
    }
    /**
     * Record AI performance metrics
     */
    async recordAIMetrics(metrics) {
        try {
            const metricData = [
                {
                    MetricName: 'AIGenerationTime',
                    Value: metrics.generationTime,
                    Unit: client_cloudwatch_1.StandardUnit.Milliseconds,
                    Dimensions: [
                        { Name: 'Environment', Value: this.environment },
                        { Name: 'Operation', Value: metrics.operation },
                        { Name: 'Model', Value: metrics.modelUsed }
                    ]
                }
            ];
            if (metrics.tokensUsed !== undefined) {
                metricData.push({
                    MetricName: 'AITokensUsed',
                    Value: metrics.tokensUsed,
                    Unit: client_cloudwatch_1.StandardUnit.Count,
                    Dimensions: [
                        { Name: 'Environment', Value: this.environment },
                        { Name: 'Operation', Value: metrics.operation },
                        { Name: 'Model', Value: metrics.modelUsed }
                    ]
                });
            }
            if (metrics.cacheHit !== undefined) {
                metricData.push({
                    MetricName: 'AICacheHit',
                    Value: metrics.cacheHit ? 1 : 0,
                    Unit: client_cloudwatch_1.StandardUnit.Count,
                    Dimensions: [
                        { Name: 'Environment', Value: this.environment },
                        { Name: 'Operation', Value: metrics.operation }
                    ]
                });
            }
            if (metrics.errorRate !== undefined) {
                metricData.push({
                    MetricName: 'AIErrorRate',
                    Value: metrics.errorRate,
                    Unit: client_cloudwatch_1.StandardUnit.Percent,
                    Dimensions: [
                        { Name: 'Environment', Value: this.environment },
                        { Name: 'Operation', Value: metrics.operation },
                        { Name: 'Model', Value: metrics.modelUsed }
                    ]
                });
            }
            await this.publishMetrics('SmartCooking/Performance/AI', metricData);
        }
        catch (error) {
            logger_1.logger.error('Failed to record AI metrics', {
                metrics,
                error: error instanceof Error ? error.message : 'Unknown error'
            });
        }
    }
    /**
     * Publish metrics to CloudWatch
     */
    async publishMetrics(namespace, metricData) {
        if (metricData.length === 0)
            return;
        // CloudWatch allows max 20 metrics per request
        const batchSize = 20;
        for (let i = 0; i < metricData.length; i += batchSize) {
            const batch = metricData.slice(i, i + batchSize);
            try {
                await this.cloudwatch.send(new client_cloudwatch_1.PutMetricDataCommand({
                    Namespace: namespace,
                    MetricData: batch.map(metric => ({
                        ...metric,
                        Timestamp: new Date()
                    }))
                }));
                logger_1.logger.debug('Published performance metrics', {
                    namespace,
                    metricCount: batch.length
                });
            }
            catch (error) {
                logger_1.logger.error('Failed to publish metrics batch', {
                    namespace,
                    batchSize: batch.length,
                    error: error instanceof Error ? error.message : 'Unknown error'
                });
            }
        }
    }
    /**
     * Create a performance timer for measuring operation duration
     */
    createTimer(operation) {
        return new PerformanceTimer(operation, this);
    }
}
exports.PerformanceMetrics = PerformanceMetrics;
/**
 * Performance timer utility class
 */
class PerformanceTimer {
    constructor(operation, metrics) {
        this.operation = operation;
        this.metrics = metrics;
        this.startTime = Date.now();
    }
    /**
     * Stop timer and record duration
     */
    stop(additionalMetrics) {
        const duration = Date.now() - this.startTime;
        logger_1.logger.debug('Performance timer stopped', {
            operation: this.operation,
            duration,
            ...additionalMetrics
        });
        return duration;
    }
    /**
     * Get elapsed time without stopping timer
     */
    elapsed() {
        return Date.now() - this.startTime;
    }
}
exports.PerformanceTimer = PerformanceTimer;
// Singleton instance
let performanceMetricsInstance = null;
function getPerformanceMetrics() {
    if (!performanceMetricsInstance) {
        performanceMetricsInstance = new PerformanceMetrics();
    }
    return performanceMetricsInstance;
}
