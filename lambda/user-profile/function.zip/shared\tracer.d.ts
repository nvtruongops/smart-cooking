/**
 * AWS X-Ray distributed tracing utility for Lambda functions
 * Provides segment and subsegment creation for detailed performance monitoring
 */
import * as AWSXRay from 'aws-xray-sdk-core';
export interface TraceMetadata {
    [key: string]: any;
}
export interface TraceAnnotations {
    [key: string]: string | number | boolean;
}
/**
 * X-Ray tracing wrapper class
 */
export declare class XRayTracer {
    private isEnabled;
    constructor();
    /**
     * Create a subsegment for an operation
     */
    captureAsyncFunc<T>(name: string, fn: (subsegment?: AWSXRay.Subsegment) => Promise<T>, annotations?: TraceAnnotations, metadata?: TraceMetadata): Promise<T>;
    /**
     * Capture a database operation
     */
    captureDatabaseOperation<T>(operation: string, tableName: string, fn: () => Promise<T>): Promise<T>;
    /**
     * Capture an external API call
     */
    captureApiCall<T>(service: string, operation: string, fn: () => Promise<T>, url?: string): Promise<T>;
    /**
     * Capture AWS SDK call (Bedrock, etc.)
     */
    captureAwsCall<T>(serviceName: string, operation: string, fn: () => Promise<T>, metadata?: TraceMetadata): Promise<T>;
    /**
     * Capture business logic operation
     */
    captureBusinessOperation<T>(operationName: string, fn: () => Promise<T>, businessData?: TraceMetadata): Promise<T>;
    /**
     * Add annotation to current segment
     */
    addAnnotation(key: string, value: string | number | boolean): void;
    /**
     * Add metadata to current segment
     */
    addMetadata(namespace: string, data: any): void;
    /**
     * Record user information
     */
    setUser(userId: string): void;
    /**
     * Get current trace ID
     */
    getTraceId(): string | undefined;
    /**
     * Check if X-Ray is enabled
     */
    isTracingEnabled(): boolean;
}
export declare const tracer: XRayTracer;
/**
 * Decorator to automatically trace async functions
 */
export declare function trace(operationName?: string, annotations?: TraceAnnotations): (target: any, propertyKey: string, descriptor: PropertyDescriptor) => PropertyDescriptor;
/**
 * Helper to measure and trace execution time
 */
export declare function traceOperation<T>(operationName: string, fn: () => Promise<T>, annotations?: TraceAnnotations, metadata?: TraceMetadata): Promise<T>;
/**
 * Capture AWS SDK clients with X-Ray
 */
export declare function captureAWS<T>(awsService: T): T;
