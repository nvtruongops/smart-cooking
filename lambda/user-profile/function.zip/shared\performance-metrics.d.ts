/**
 * Performance metrics collection and reporting service
 * Tracks optimization metrics for Smart Cooking MVP
 */
export declare class PerformanceMetrics {
    private cloudwatch;
    private environment;
    constructor();
    /**
     * Record cache performance metrics
     */
    recordCacheMetrics(metrics: {
        operation: string;
        hitRate: number;
        responseTime: number;
        cacheSize?: number;
    }): Promise<void>;
    /**
     * Record database query performance metrics
     */
    recordDatabaseMetrics(metrics: {
        operation: string;
        queryTime: number;
        itemCount: number;
        indexUsed?: string;
        filterApplied?: boolean;
    }): Promise<void>;
    /**
     * Record Lambda function performance metrics
     */
    recordLambdaMetrics(metrics: {
        functionName: string;
        duration: number;
        memoryUsed: number;
        memoryAllocated: number;
        coldStart?: boolean;
        errorCount?: number;
    }): Promise<void>;
    /**
     * Record cost optimization metrics
     */
    recordCostOptimizationMetrics(metrics: {
        operation: string;
        costSavings: number;
        dbUsageRatio: number;
        aiUsageRatio: number;
        optimizationStrategy: string;
    }): Promise<void>;
    /**
     * Record AI performance metrics
     */
    recordAIMetrics(metrics: {
        operation: string;
        generationTime: number;
        tokensUsed?: number;
        modelUsed: string;
        cacheHit?: boolean;
        errorRate?: number;
    }): Promise<void>;
    /**
     * Publish metrics to CloudWatch
     */
    private publishMetrics;
    /**
     * Create a performance timer for measuring operation duration
     */
    createTimer(operation: string): PerformanceTimer;
}
/**
 * Performance timer utility class
 */
export declare class PerformanceTimer {
    private startTime;
    private operation;
    private metrics;
    constructor(operation: string, metrics: PerformanceMetrics);
    /**
     * Stop timer and record duration
     */
    stop(additionalMetrics?: Record<string, any>): number;
    /**
     * Get elapsed time without stopping timer
     */
    elapsed(): number;
}
export declare function getPerformanceMetrics(): PerformanceMetrics;
