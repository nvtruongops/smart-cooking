"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateUUID = generateUUID;
exports.normalizeText = normalizeText;
exports.calculateSimilarity = calculateSimilarity;
exports.validateEmail = validateEmail;
exports.validateAge = validateAge;
exports.sanitizeInput = sanitizeInput;
exports.formatTimestamp = formatTimestamp;
exports.parseJSON = parseJSON;
exports.logStructured = logStructured;
exports.getUserIdFromEvent = getUserIdFromEvent;
exports.validateRating = validateRating;
exports.calculateAverageRating = calculateAverageRating;
exports.shouldAutoApprove = shouldAutoApprove;
exports.createCacheKey = createCacheKey;
exports.isValidUUID = isValidUUID;
exports.getAgeFromBirthYear = getAgeFromBirthYear;
exports.extractBirthYear = extractBirthYear;
exports.delay = delay;
exports.retryWithBackoff = retryWithBackoff;
exports.retryWithExponentialBackoff = retryWithExponentialBackoff;
const uuid_1 = require("uuid");
function generateUUID() {
    return (0, uuid_1.v4)();
}
function normalizeText(text) {
    return text
        .toLowerCase()
        .trim()
        .replace(/[àáạảãâầấậẩẫăằắặẳẵ]/g, 'a')
        .replace(/[èéẹẻẽêềếệểễ]/g, 'e')
        .replace(/[ìíịỉĩ]/g, 'i')
        .replace(/[òóọỏõôồốộổỗơờớợởỡ]/g, 'o')
        .replace(/[ùúụủũưừứựửữ]/g, 'u')
        .replace(/[ỳýỵỷỹ]/g, 'y')
        .replace(/đ/g, 'd')
        .replace(/[^a-z0-9\s]/g, '')
        .replace(/\s+/g, ' ')
        .trim();
}
function calculateSimilarity(str1, str2) {
    const longer = str1.length > str2.length ? str1 : str2;
    const shorter = str1.length > str2.length ? str2 : str1;
    if (longer.length === 0) {
        return 1.0;
    }
    const distance = levenshteinDistance(longer, shorter);
    return (longer.length - distance) / longer.length;
}
function levenshteinDistance(str1, str2) {
    const matrix = [];
    for (let i = 0; i <= str2.length; i++) {
        matrix[i] = [i];
    }
    for (let j = 0; j <= str1.length; j++) {
        matrix[0][j] = j;
    }
    for (let i = 1; i <= str2.length; i++) {
        for (let j = 1; j <= str1.length; j++) {
            if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
                matrix[i][j] = matrix[i - 1][j - 1];
            }
            else {
                matrix[i][j] = Math.min(matrix[i - 1][j - 1] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j] + 1);
            }
        }
    }
    return matrix[str2.length][str1.length];
}
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}
function validateAge(birthDate) {
    const birth = new Date(birthDate);
    const today = new Date();
    const age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
        return age - 1 >= 13;
    }
    return age >= 13;
}
function sanitizeInput(input, maxLength = 100) {
    return input
        .trim()
        .replace(/[<>\"'&]/g, '') // Remove potential XSS characters
        .substring(0, maxLength);
}
function formatTimestamp(date = new Date()) {
    return date.toISOString();
}
function parseJSON(jsonString) {
    if (!jsonString) {
        return null;
    }
    try {
        return JSON.parse(jsonString);
    }
    catch (error) {
        throw new Error('Invalid JSON format');
    }
}
function logStructured(level, message, metadata = {}) {
    console.log(JSON.stringify({
        timestamp: formatTimestamp(),
        level,
        message,
        ...metadata,
    }));
}
function getUserIdFromEvent(event) {
    const userId = event.requestContext?.authorizer?.claims?.sub;
    if (!userId) {
        throw new Error('User ID not found in request context');
    }
    return userId;
}
function validateRating(rating) {
    return Number.isInteger(rating) && rating >= 1 && rating <= 5;
}
function calculateAverageRating(ratings) {
    if (ratings.length === 0)
        return 0;
    const sum = ratings.reduce((acc, r) => acc + r.rating, 0);
    return Math.round((sum / ratings.length) * 10) / 10; // Round to 1 decimal place
}
function shouldAutoApprove(averageRating, minRatingCount = 3, threshold = 4.0) {
    return averageRating >= threshold && minRatingCount >= 3;
}
function createCacheKey(prefix, ...parts) {
    return `${prefix}:${parts.join(':')}`;
}
function isValidUUID(uuid) {
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    return uuidRegex.test(uuid);
}
function getAgeFromBirthYear(birthYear) {
    return new Date().getFullYear() - birthYear;
}
function extractBirthYear(birthDate) {
    try {
        const date = new Date(birthDate);
        return date.getFullYear();
    }
    catch {
        return null;
    }
}
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
function retryWithBackoff(fn, maxRetries = 3, baseDelay = 1000) {
    return retryWithExponentialBackoff(fn, { maxRetries, baseDelay });
}
async function retryWithExponentialBackoff(fn, options = {}) {
    const { maxRetries = 3, baseDelay = 1000, maxDelay = 30000, shouldRetry = () => true, onRetry, } = options;
    let lastError;
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            const result = await fn();
            return result;
        }
        catch (error) {
            lastError = error instanceof Error ? error : new Error(String(error));
            // Check if we should retry this error
            if (!shouldRetry(lastError)) {
                throw lastError;
            }
            // Don't retry if this was the last attempt
            if (attempt === maxRetries) {
                throw lastError;
            }
            // Calculate delay with exponential backoff and jitter
            const exponentialDelay = baseDelay * Math.pow(2, attempt - 1);
            const jitter = Math.random() * 0.3 * exponentialDelay; // Add up to 30% jitter
            const delayMs = Math.min(exponentialDelay + jitter, maxDelay);
            logStructured('WARN', `Retry attempt ${attempt}/${maxRetries}`, {
                error: lastError.message,
                nextRetryInMs: Math.round(delayMs),
            });
            // Call retry callback if provided
            if (onRetry) {
                onRetry(lastError, attempt);
            }
            await delay(delayMs);
        }
    }
    throw lastError;
}
