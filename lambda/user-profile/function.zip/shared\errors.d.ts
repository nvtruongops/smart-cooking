/**
 * Centralized Error Handling System
 * Provides standardized error classes and HTTP response formatting
 */
export declare enum ErrorCode {
    BAD_REQUEST = "BAD_REQUEST",
    UNAUTHORIZED = "UNAUTHORIZED",
    FORBIDDEN = "FORBIDDEN",
    NOT_FOUND = "NOT_FOUND",
    CONFLICT = "CONFLICT",
    VALIDATION_ERROR = "VALIDATION_ERROR",
    RATE_LIMIT_EXCEEDED = "RATE_LIMIT_EXCEEDED",
    INTERNAL_ERROR = "INTERNAL_ERROR",
    SERVICE_UNAVAILABLE = "SERVICE_UNAVAILABLE",
    AI_SERVICE_ERROR = "AI_SERVICE_ERROR",
    DATABASE_ERROR = "DATABASE_ERROR",
    TIMEOUT = "TIMEOUT"
}
export interface ErrorDetails {
    code: ErrorCode;
    message: string;
    statusCode: number;
    details?: any;
    recoverable?: boolean;
    recoverySuggestion?: string;
}
/**
 * Base application error class
 */
export declare class AppError extends Error {
    readonly code: ErrorCode;
    readonly statusCode: number;
    readonly details?: any;
    readonly recoverable: boolean;
    readonly recoverySuggestion?: string;
    readonly timestamp: string;
    constructor(errorDetails: ErrorDetails);
    toJSON(): {
        error: {
            code: ErrorCode;
            message: string;
            details: any;
            recoverable: boolean;
            recoverySuggestion: string | undefined;
            timestamp: string;
        };
    };
}
/**
 * Client error classes (4xx)
 */
export declare class BadRequestError extends AppError {
    constructor(message: string, details?: any);
}
export declare class UnauthorizedError extends AppError {
    constructor(message?: string);
}
export declare class ForbiddenError extends AppError {
    constructor(message?: string);
}
export declare class NotFoundError extends AppError {
    constructor(resource?: string);
}
export declare class ValidationError extends AppError {
    constructor(message: string, validationErrors?: any);
}
export declare class ConflictError extends AppError {
    constructor(message: string, details?: any);
}
export declare class RateLimitError extends AppError {
    constructor(retryAfter?: number);
}
/**
 * Server error classes (5xx)
 */
export declare class InternalError extends AppError {
    constructor(message?: string, details?: any);
}
export declare class ServiceUnavailableError extends AppError {
    constructor(service: string, retryAfter?: number);
}
export declare class AIServiceError extends AppError {
    constructor(message?: string, details?: any, recoverable?: boolean);
}
export declare class DatabaseError extends AppError {
    constructor(message?: string, details?: any);
}
export declare class TimeoutError extends AppError {
    constructor(operation: string);
}
/**
 * Error response formatter for API Gateway
 */
export declare function formatErrorResponse(error: Error | AppError): {
    statusCode: number;
    body: string;
    headers: Record<string, string>;
};
/**
 * Determine if error is transient and should be retried
 */
export declare function isTransientError(error: Error | AppError): boolean;
/**
 * Get retry delay for transient errors (exponential backoff)
 */
export declare function getRetryDelay(attempt: number, baseDelay?: number): number;
