"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OptimizedQueries = void 0;
exports.getOptimizedQueries = getOptimizedQueries;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const util_dynamodb_1 = require("@aws-sdk/util-dynamodb");
const logger_1 = require("./logger");
/**
 * Optimized DynamoDB query patterns for Smart Cooking MVP
 * Implements efficient query strategies and batch operations
 */
class OptimizedQueries {
    constructor() {
        this.client = new client_dynamodb_1.DynamoDBClient({ region: process.env.AWS_REGION });
        this.tableName = process.env.DYNAMODB_TABLE;
    }
    /**
     * Optimized recipe search using GSI with efficient filtering
     */
    async searchRecipes(filters) {
        const startTime = Date.now();
        const { cuisine, cookingMethod, mealType, isApproved = true, limit = 20, lastEvaluatedKey } = filters;
        try {
            // Build GSI1SK for efficient filtering
            const gsi1SKParts = [cuisine, cookingMethod, mealType].filter(Boolean);
            const gsi1SK = gsi1SKParts.length > 0 ? gsi1SKParts.join('#') : '';
            let keyConditionExpression = 'GSI1PK = :pk';
            const expressionAttributeValues = {
                ':pk': 'RECIPE'
            };
            if (gsi1SK) {
                keyConditionExpression += ' AND begins_with(GSI1SK, :sk)';
                expressionAttributeValues[':sk'] = gsi1SK;
            }
            // Add approval filter
            let filterExpression = '';
            if (isApproved !== undefined) {
                filterExpression = 'is_approved = :approved';
                expressionAttributeValues[':approved'] = isApproved;
            }
            const response = await this.client.send(new client_dynamodb_1.QueryCommand({
                TableName: this.tableName,
                IndexName: 'GSI1',
                KeyConditionExpression: keyConditionExpression,
                FilterExpression: filterExpression || undefined,
                ExpressionAttributeValues: (0, util_dynamodb_1.marshall)(expressionAttributeValues),
                Limit: limit,
                ScanIndexForward: false, // Get newest first
                ExclusiveStartKey: lastEvaluatedKey
            }));
            const recipes = response.Items?.map(item => (0, util_dynamodb_1.unmarshall)(item)) || [];
            const queryTime = Date.now() - startTime;
            logger_1.logger.info('Recipe search completed', {
                filters,
                resultCount: recipes.length,
                queryTime,
                hasMore: !!response.LastEvaluatedKey
            });
            return {
                recipes,
                lastEvaluatedKey: response.LastEvaluatedKey,
                count: recipes.length
            };
        }
        catch (error) {
            const queryTime = Date.now() - startTime;
            logger_1.logger.error('Recipe search failed', {
                filters,
                queryTime,
                error: error.message
            });
            throw error;
        }
    }
    /**
     * Batch get user cooking history with optimized pagination
     */
    async getUserCookingHistory(userId, options = {}) {
        const startTime = Date.now();
        const { limit = 50, lastEvaluatedKey, status } = options;
        try {
            let filterExpression = '';
            const expressionAttributeValues = {
                ':pk': `USER#${userId}`,
                ':sk': 'COOKING_SESSION#'
            };
            if (status) {
                filterExpression = '#status = :status';
                expressionAttributeValues[':status'] = status;
            }
            const response = await this.client.send(new client_dynamodb_1.QueryCommand({
                TableName: this.tableName,
                KeyConditionExpression: 'PK = :pk AND begins_with(SK, :sk)',
                FilterExpression: filterExpression || undefined,
                ExpressionAttributeValues: (0, util_dynamodb_1.marshall)(expressionAttributeValues),
                ExpressionAttributeNames: status ? { '#status': 'status' } : undefined,
                Limit: limit,
                ScanIndexForward: false, // Most recent first
                ExclusiveStartKey: lastEvaluatedKey
            }));
            const sessions = response.Items?.map(item => (0, util_dynamodb_1.unmarshall)(item)) || [];
            const queryTime = Date.now() - startTime;
            logger_1.logger.info('Cooking history query completed', {
                userId,
                options,
                resultCount: sessions.length,
                queryTime
            });
            return {
                sessions,
                lastEvaluatedKey: response.LastEvaluatedKey,
                count: sessions.length
            };
        }
        catch (error) {
            const queryTime = Date.now() - startTime;
            logger_1.logger.error('Cooking history query failed', {
                userId,
                options,
                queryTime,
                error: error.message
            });
            throw error;
        }
    }
    /**
     * Optimized ingredient validation with batch operations
     */
    async validateIngredientsBatch(ingredients) {
        const startTime = Date.now();
        if (ingredients.length === 0) {
            return { results: [], validCount: 0, invalidCount: 0 };
        }
        try {
            // Batch get for better performance (max 100 items per batch)
            const batches = [];
            for (let i = 0; i < ingredients.length; i += 100) {
                batches.push(ingredients.slice(i, i + 100));
            }
            const allResults = [];
            for (const batch of batches) {
                const keys = batch.map(ingredient => ({
                    PK: { S: `INGREDIENT#${ingredient.toLowerCase()}` },
                    SK: { S: 'MASTER' }
                }));
                const response = await this.client.send(new client_dynamodb_1.BatchGetItemCommand({
                    RequestItems: {
                        [this.tableName]: {
                            Keys: keys
                        }
                    }
                }));
                const found = response.Responses?.[this.tableName]?.map(item => (0, util_dynamodb_1.unmarshall)(item)) || [];
                // Process results for this batch
                const batchResults = batch.map(ingredient => {
                    const foundItem = found.find(item => item.name.toLowerCase() === ingredient.toLowerCase() ||
                        item.aliases?.some((alias) => alias.toLowerCase() === ingredient.toLowerCase()));
                    return {
                        ingredient,
                        is_valid: !!foundItem,
                        master_data: foundItem || null,
                        suggestions: foundItem ? [] : this.generateSuggestions(ingredient, found)
                    };
                });
                allResults.push(...batchResults);
            }
            const validCount = allResults.filter(r => r.is_valid).length;
            const invalidCount = allResults.length - validCount;
            const queryTime = Date.now() - startTime;
            logger_1.logger.info('Batch ingredient validation completed', {
                totalIngredients: ingredients.length,
                validCount,
                invalidCount,
                queryTime,
                batchCount: batches.length
            });
            return {
                results: allResults,
                validCount,
                invalidCount
            };
        }
        catch (error) {
            const queryTime = Date.now() - startTime;
            logger_1.logger.error('Batch ingredient validation failed', {
                ingredientCount: ingredients.length,
                queryTime,
                error: error.message
            });
            throw error;
        }
    }
    /**
     * Get popular recipes using GSI2 (sorted by rating/popularity)
     */
    async getPopularRecipes(options = {}) {
        const startTime = Date.now();
        const { limit = 20, minRating = 4.0, lastEvaluatedKey } = options;
        try {
            let filterExpression = 'average_rating >= :minRating AND is_approved = :approved';
            const expressionAttributeValues = {
                ':pk': 'RECIPE_POPULAR',
                ':minRating': minRating,
                ':approved': true
            };
            const response = await this.client.send(new client_dynamodb_1.QueryCommand({
                TableName: this.tableName,
                IndexName: 'GSI2',
                KeyConditionExpression: 'GSI2PK = :pk',
                FilterExpression: filterExpression,
                ExpressionAttributeValues: (0, util_dynamodb_1.marshall)(expressionAttributeValues),
                Limit: limit,
                ScanIndexForward: false, // Highest rated first
                ExclusiveStartKey: lastEvaluatedKey
            }));
            const recipes = response.Items?.map(item => (0, util_dynamodb_1.unmarshall)(item)) || [];
            const queryTime = Date.now() - startTime;
            logger_1.logger.info('Popular recipes query completed', {
                options,
                resultCount: recipes.length,
                queryTime
            });
            return {
                recipes,
                lastEvaluatedKey: response.LastEvaluatedKey,
                count: recipes.length
            };
        }
        catch (error) {
            const queryTime = Date.now() - startTime;
            logger_1.logger.error('Popular recipes query failed', {
                options,
                queryTime,
                error: error.message
            });
            throw error;
        }
    }
    /**
     * Generate ingredient suggestions for fuzzy matching
     */
    generateSuggestions(ingredient, masterIngredients) {
        const suggestions = [];
        const inputLower = ingredient.toLowerCase();
        for (const master of masterIngredients) {
            const masterName = master.name.toLowerCase();
            // Simple fuzzy matching - can be enhanced with more sophisticated algorithms
            if (this.calculateSimilarity(inputLower, masterName) > 0.6) {
                suggestions.push(master.name);
            }
            // Check aliases
            if (master.aliases) {
                for (const alias of master.aliases) {
                    if (this.calculateSimilarity(inputLower, alias.toLowerCase()) > 0.6) {
                        suggestions.push(master.name);
                        break;
                    }
                }
            }
        }
        return suggestions.slice(0, 3); // Return top 3 suggestions
    }
    /**
     * Simple string similarity calculation (Levenshtein distance based)
     */
    calculateSimilarity(str1, str2) {
        const longer = str1.length > str2.length ? str1 : str2;
        const shorter = str1.length > str2.length ? str2 : str1;
        if (longer.length === 0)
            return 1.0;
        const distance = this.levenshteinDistance(longer, shorter);
        return (longer.length - distance) / longer.length;
    }
    /**
     * Calculate Levenshtein distance between two strings
     */
    levenshteinDistance(str1, str2) {
        const matrix = [];
        for (let i = 0; i <= str2.length; i++) {
            matrix[i] = [i];
        }
        for (let j = 0; j <= str1.length; j++) {
            matrix[0][j] = j;
        }
        for (let i = 1; i <= str2.length; i++) {
            for (let j = 1; j <= str1.length; j++) {
                if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
                    matrix[i][j] = matrix[i - 1][j - 1];
                }
                else {
                    matrix[i][j] = Math.min(matrix[i - 1][j - 1] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j] + 1);
                }
            }
        }
        return matrix[str2.length][str1.length];
    }
}
exports.OptimizedQueries = OptimizedQueries;
// Singleton instance
let queriesInstance = null;
function getOptimizedQueries() {
    if (!queriesInstance) {
        queriesInstance = new OptimizedQueries();
    }
    return queriesInstance;
}
