/**
 * Social Features Cost Monitoring
 * Task 18.2: Monitor and reduce DynamoDB read/write costs for social features
 *
 * Tracks and analyzes DynamoDB usage for social features:
 * - Friend operations
 * - Post/Comment/Reaction operations
 * - Feed generation
 * - Notification delivery
 */
interface OperationMetrics {
    operation: string;
    readUnits: number;
    writeUnits: number;
    queryCount: number;
    itemsProcessed: number;
    cacheHit?: boolean;
    executionTimeMs: number;
}
export declare class SocialCostMonitor {
    /**
     * Track DynamoDB operation costs
     */
    trackOperation(metrics: OperationMetrics): Promise<void>;
    /**
     * Estimate cost based on DynamoDB read/write units
     * Pricing (as of 2024, on-demand):
     * - Read: $0.25 per million read request units
     * - Write: $1.25 per million write request units
     */
    private estimateCost;
    /**
     * Track feed generation cost
     * High-cost operation due to multiple queries
     */
    trackFeedGeneration(params: {
        userId: string;
        friendCount: number;
        publicPostsScanned: number;
        friendsPostsScanned: number;
        totalPostsReturned: number;
        friendsCached: boolean;
        executionTimeMs: number;
    }): Promise<void>;
    /**
     * Track notification query cost
     * Optimized with sparse index for unread notifications
     */
    trackNotificationQuery(params: {
        userId: string;
        filter: 'UNREAD' | 'ALL';
        itemsReturned: number;
        usesSparseIndex: boolean;
        executionTimeMs: number;
    }): Promise<void>;
    /**
     * Track friend operations (queries friend list frequently)
     */
    trackFriendOperation(params: {
        operation: 'GetFriends' | 'SendRequest' | 'AcceptRequest' | 'RemoveFriend';
        userId: string;
        friendCount?: number;
        cacheHit?: boolean;
        executionTimeMs: number;
    }): Promise<void>;
    /**
     * Track post/comment/reaction operations
     */
    trackContentOperation(params: {
        operation: 'CreatePost' | 'CreateComment' | 'CreateReaction' | 'GetPost' | 'GetComments';
        itemCount: number;
        notificationCreated: boolean;
        executionTimeMs: number;
    }): Promise<void>;
    /**
     * Generate daily cost report
     * Should be run as scheduled Lambda (CloudWatch Events)
     */
    generateCostReport(startDate: Date, endDate: Date): Promise<{
        totalReadUnits: number;
        totalWriteUnits: number;
        totalCost: number;
        operationBreakdown: Record<string, {
            reads: number;
            writes: number;
            cost: number;
        }>;
        recommendations: string[];
    }>;
    /**
     * Check if costs exceed threshold and send alert
     */
    checkCostThreshold(dailyReadUnits: number, dailyWriteUnits: number): Promise<void>;
}
export declare function getSocialCostMonitor(): SocialCostMonitor;
export {};
