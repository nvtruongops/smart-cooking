/**
 * Graceful Degradation Utilities
 * Handles service failures with fallback mechanisms
 */
export interface GracefulDegradationOptions {
    serviceName: string;
    enableFallback: boolean;
    fallbackFn?: () => Promise<any>;
    timeoutMs?: number;
    onError?: (error: Error) => void;
}
/**
 * Execute operation with graceful degradation
 * Falls back to alternative function if primary fails
 */
export declare function withGracefulDegradation<T>(primaryFn: () => Promise<T>, options: GracefulDegradationOptions): Promise<T>;
/**
 * AI Service wrapper with graceful degradation
 */
export declare class AIServiceWrapper {
    private static failureCount;
    private static lastFailureTime;
    private static readonly MAX_FAILURES;
    private static readonly FAILURE_WINDOW_MS;
    /**
     * Execute AI service call with circuit breaker pattern
     */
    static execute<T>(aiFn: () => Promise<T>, fallbackFn?: () => Promise<T>, timeoutMs?: number): Promise<T>;
    /**
     * Check if circuit breaker should be open
     */
    private static isCircuitOpen;
    /**
     * Record a failure
     */
    private static recordFailure;
    /**
     * Reset failure count
     */
    private static resetFailureCount;
    /**
     * Determine if AI error is recoverable
     */
    private static isRecoverableAIError;
}
/**
 * Database operation wrapper with graceful degradation
 */
export declare function withDatabaseFallback<T>(operation: () => Promise<T>, fallbackValue?: T): Promise<T>;
/**
 * Partial success handler for batch operations
 */
export interface BatchResult<T> {
    successful: T[];
    failed: Array<{
        item: any;
        error: Error;
    }>;
    partialSuccess: boolean;
}
export declare function executeBatchWithPartialSuccess<TInput, TOutput>(items: TInput[], processFn: (item: TInput) => Promise<TOutput>): Promise<BatchResult<TOutput>>;
/**
 * Health check utility
 */
export interface HealthCheckResult {
    service: string;
    healthy: boolean;
    message?: string;
    responseTimeMs?: number;
}
export declare function checkServiceHealth(serviceName: string, healthCheckFn: () => Promise<void>, timeoutMs?: number): Promise<HealthCheckResult>;
