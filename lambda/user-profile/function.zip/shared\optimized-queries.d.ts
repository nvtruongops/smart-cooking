/**
 * Optimized DynamoDB query patterns for Smart Cooking MVP
 * Implements efficient query strategies and batch operations
 */
export declare class OptimizedQueries {
    private client;
    private tableName;
    constructor();
    /**
     * Optimized recipe search using GSI with efficient filtering
     */
    searchRecipes(filters: {
        cuisine?: string;
        cookingMethod?: string;
        mealType?: string;
        isApproved?: boolean;
        limit?: number;
        lastEvaluatedKey?: any;
    }): Promise<{
        recipes: any[];
        lastEvaluatedKey?: any;
        count: number;
    }>;
    /**
     * Batch get user cooking history with optimized pagination
     */
    getUserCookingHistory(userId: string, options?: {
        limit?: number;
        lastEvaluatedKey?: any;
        status?: 'cooking' | 'completed';
    }): Promise<{
        sessions: any[];
        lastEvaluatedKey?: any;
        count: number;
    }>;
    /**
     * Optimized ingredient validation with batch operations
     */
    validateIngredientsBatch(ingredients: string[]): Promise<{
        results: Array<{
            ingredient: string;
            is_valid: boolean;
            master_data?: any;
            suggestions?: string[];
        }>;
        validCount: number;
        invalidCount: number;
    }>;
    /**
     * Get popular recipes using GSI2 (sorted by rating/popularity)
     */
    getPopularRecipes(options?: {
        limit?: number;
        minRating?: number;
        lastEvaluatedKey?: any;
    }): Promise<{
        recipes: any[];
        lastEvaluatedKey?: any;
        count: number;
    }>;
    /**
     * Generate ingredient suggestions for fuzzy matching
     */
    private generateSuggestions;
    /**
     * Simple string similarity calculation (Levenshtein distance based)
     */
    private calculateSimilarity;
    /**
     * Calculate Levenshtein distance between two strings
     */
    private levenshteinDistance;
}
export declare function getOptimizedQueries(): OptimizedQueries;
