"use strict";
/**
 * Structured JSON logging utility for Lambda functions
 * Provides consistent log formatting with levels, metadata, and correlation IDs
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = exports.LogLevel = void 0;
exports.measureTime = measureTime;
exports.createChildLogger = createChildLogger;
var LogLevel;
(function (LogLevel) {
    LogLevel["DEBUG"] = "DEBUG";
    LogLevel["INFO"] = "INFO";
    LogLevel["WARN"] = "WARN";
    LogLevel["ERROR"] = "ERROR";
})(LogLevel || (exports.LogLevel = LogLevel = {}));
class Logger {
    constructor() {
        this.context = {};
        // Set log level from environment variable (defaults to INFO)
        const envLogLevel = process.env.LOG_LEVEL?.toUpperCase();
        this.logLevel = (envLogLevel && LogLevel[envLogLevel]) || LogLevel.INFO;
    }
    /**
     * Set context that will be included in all subsequent logs
     */
    setContext(context) {
        this.context = { ...this.context, ...context };
    }
    /**
     * Clear the logging context
     */
    clearContext() {
        this.context = {};
    }
    /**
     * Get current context
     */
    getContext() {
        return { ...this.context };
    }
    /**
     * Initialize logger from Lambda event
     */
    initFromEvent(event) {
        const requestId = event.requestContext?.requestId;
        const userId = event.requestContext?.authorizer?.claims?.sub;
        const traceId = process.env._X_AMZN_TRACE_ID;
        this.setContext({
            requestId,
            userId,
            functionName: process.env.AWS_LAMBDA_FUNCTION_NAME,
            functionVersion: process.env.AWS_LAMBDA_FUNCTION_VERSION,
            traceId
        });
    }
    /**
     * Check if a log level should be logged
     */
    shouldLog(level) {
        const levels = [LogLevel.DEBUG, LogLevel.INFO, LogLevel.WARN, LogLevel.ERROR];
        const currentLevelIndex = levels.indexOf(this.logLevel);
        const targetLevelIndex = levels.indexOf(level);
        return targetLevelIndex >= currentLevelIndex;
    }
    /**
     * Core logging function
     */
    log(level, message, metadata = {}) {
        if (!this.shouldLog(level)) {
            return;
        }
        const logEntry = {
            timestamp: new Date().toISOString(),
            level,
            message,
            ...this.context,
            ...metadata
        };
        // Use console methods based on level with circular reference handling
        const seen = new WeakSet();
        const output = JSON.stringify(logEntry, (key, value) => {
            if (typeof value === 'object' && value !== null) {
                // Handle circular references
                if (seen.has(value)) {
                    return '[Circular Reference]';
                }
                seen.add(value);
            }
            return value;
        });
        switch (level) {
            case LogLevel.ERROR:
                console.error(output);
                break;
            case LogLevel.WARN:
                console.warn(output);
                break;
            case LogLevel.INFO:
                console.info(output);
                break;
            case LogLevel.DEBUG:
            default:
                console.log(output);
                break;
        }
    }
    /**
     * Log debug message
     */
    debug(message, metadata) {
        this.log(LogLevel.DEBUG, message, metadata);
    }
    /**
     * Log info message
     */
    info(message, metadata) {
        this.log(LogLevel.INFO, message, metadata);
    }
    /**
     * Log warning message
     */
    warn(message, metadata) {
        this.log(LogLevel.WARN, message, metadata);
    }
    /**
     * Log error message
     */
    error(message, error, metadata) {
        const errorMetadata = error ? {
            error: {
                name: error.name,
                message: error.message,
                stack: error.stack,
                code: error.code,
                statusCode: error.statusCode,
                ...error
            }
        } : {};
        this.log(LogLevel.ERROR, message, { ...errorMetadata, ...metadata });
    }
    /**
     * Log the start of a Lambda function execution
     */
    logFunctionStart(functionName, event) {
        this.info(`Lambda function started: ${functionName}`, {
            event: {
                httpMethod: event.httpMethod,
                path: event.path,
                resource: event.resource,
                queryStringParameters: event.queryStringParameters
            }
        });
    }
    /**
     * Log the end of a Lambda function execution
     */
    logFunctionEnd(functionName, statusCode, duration) {
        this.info(`Lambda function completed: ${functionName}`, {
            statusCode,
            durationMs: duration
        });
    }
    /**
     * Log performance metrics
     */
    logPerformance(operation, duration, metadata) {
        this.info(`Performance metric: ${operation}`, {
            operation,
            durationMs: duration,
            ...metadata
        });
    }
    /**
     * Log database operation
     */
    logDatabaseOperation(operation, table, duration, metadata) {
        this.debug(`Database operation: ${operation}`, {
            operation,
            table,
            durationMs: duration,
            ...metadata
        });
    }
    /**
     * Log external API call
     */
    logApiCall(service, operation, duration, metadata) {
        this.debug(`External API call: ${service}.${operation}`, {
            service,
            operation,
            durationMs: duration,
            ...metadata
        });
    }
    /**
     * Log business metric
     */
    logBusinessMetric(metric, value, unit, metadata) {
        this.info(`Business metric: ${metric}`, {
            metric,
            value,
            unit,
            ...metadata
        });
    }
    /**
     * Log security event
     */
    logSecurityEvent(event, severity, metadata) {
        this.warn(`Security event: ${event}`, {
            securityEvent: event,
            severity,
            ...metadata
        });
    }
}
// Export singleton instance
exports.logger = new Logger();
/**
 * Helper to measure execution time
 */
async function measureTime(operation, fn, logResult = true) {
    const start = Date.now();
    try {
        const result = await fn();
        const duration = Date.now() - start;
        if (logResult) {
            exports.logger.logPerformance(operation, duration, { success: true });
        }
        return result;
    }
    catch (error) {
        const duration = Date.now() - start;
        exports.logger.logPerformance(operation, duration, { success: false });
        throw error;
    }
}
/**
 * Helper to create a child logger with additional context
 */
function createChildLogger(additionalContext) {
    const childLogger = new Logger();
    childLogger.setContext({ ...exports.logger.getContext(), ...additionalContext });
    return childLogger;
}
