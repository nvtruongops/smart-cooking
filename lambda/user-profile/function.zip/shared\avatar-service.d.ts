/**
 * Avatar Upload Service
 * Handles avatar upload to S3 with default avatar logic
 */
export interface UploadAvatarRequest {
    user_id: string;
    image_data?: string;
    content_type?: string;
}
export interface AvatarResult {
    avatar_url: string;
    avatar_key: string;
    is_default: boolean;
}
export declare class AvatarService {
    /**
     * Set default avatar for new user by copying from default location
     * s3:default/avatar.png -> s3:userID/avatar/avatar.png
     */
    static setDefaultAvatar(userId: string): Promise<AvatarResult>;
    /**
     * Upload custom avatar for user
     * s3:userID/avatar/avatar.png
     */
    static uploadAvatar(request: UploadAvatarRequest): Promise<AvatarResult>;
    /**
     * Get file extension from content type
     */
    private static getFileExtension;
}
