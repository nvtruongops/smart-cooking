import { APIGatewayEvent, APIResponse } from '../shared/types';
export declare const handler: (event: APIGatewayEvent) => Promise<APIResponse>;
