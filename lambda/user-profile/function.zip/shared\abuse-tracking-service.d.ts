/**
 * User Abuse Tracking Service
 *
 * Tracks user violations and enforces progressive penalties:
 * - Warning 1-2: Soft warning
 * - Warning 3-4: Strong warning
 * - Warning 5+: Report to admin dashboard
 * - Weekly reset: Violations reset after 7 days
 *
 * Storage: DynamoDB with TTL for auto-cleanup
 */
export interface AbuseRecord {
    user_id: string;
    violation_type: 'spam_input' | 'sql_injection' | 'xss_attempt' | 'fake_rating' | 'bot_behavior' | 'inappropriate_content';
    severity: 'low' | 'medium' | 'high' | 'critical';
    evidence: any;
    timestamp: string;
    week_key: string;
}
export interface AbuseStats {
    total_violations: number;
    this_week_violations: number;
    last_violation: string;
    severity_breakdown: {
        low: number;
        medium: number;
        high: number;
        critical: number;
    };
    should_notify_admin: boolean;
    penalty_level: 'none' | 'warning' | 'restricted' | 'suspended';
}
export interface AdminNotification {
    notification_id: string;
    user_id: string;
    violation_count: number;
    violations: AbuseRecord[];
    created_at: string;
    status: 'pending' | 'reviewed' | 'resolved';
}
export declare class AbuseTrackingService {
    private static readonly ADMIN_NOTIFICATION_THRESHOLD;
    private static readonly AUTO_SUSPEND_THRESHOLD;
    private static readonly WEEK_RESET_DAYS;
    private static readonly RECORD_TTL_DAYS;
    /**
     * Get current week key (YYYY-WW format)
     */
    private static getCurrentWeekKey;
    /**
     * Record a violation
     */
    static recordViolation(userId: string, violationType: AbuseRecord['violation_type'], severity: AbuseRecord['severity'], evidence: any): Promise<AbuseStats>;
    /**
     * Get abuse statistics for a user
     */
    static getAbuseStats(userId: string): Promise<AbuseStats>;
    /**
     * Notify admin dashboard about user violations
     */
    private static notifyAdmin;
    /**
     * Auto-suspend user account
     */
    private static autoSuspendUser;
    /**
     * Escalate critical case to admin
     */
    private static escalateToAdmin;
    /**
     * Get violations for current week (for admin dashboard)
     */
    static getWeeklyViolations(weekKey?: string): Promise<any[]>;
    /**
     * Get pending admin notifications
     */
    static getPendingAdminNotifications(): Promise<AdminNotification[]>;
    /**
     * Check if user is currently suspended
     */
    static isUserSuspended(userId: string): Promise<boolean>;
    /**
     * Get violation history for a user (for admin review)
     */
    static getUserViolationHistory(userId: string, limit?: number): Promise<AbuseRecord[]>;
    /**
     * Weekly cleanup job (can be Lambda cron)
     * Note: Records auto-delete via TTL after 30 days
     * This is just for reporting/analytics
     */
    static weeklyCleanupReport(): Promise<any>;
}
